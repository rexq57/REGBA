

This game was made for Kraln's Thanksgiving Harvest Compo 2006.  It kind of sucks because I first thought it was due on the 27th of November.  When I saw it was due on the 20th, I had to scramble to finish it.  I started it on the 20th and will release the awful source once i organize it. 
The goal of the game is to try to avoid the blocks by ducking and jumping.  After your score reaches certain scores, the speed of the blocks will increase.  Score 128 or greater and you will have successfully avoided being a Thanksgiving dinner. 

Keys:
A - Jump
Down - Duck
Left - move left
Right - move right


Thanks for playing, Visit freewebs.com/xuron.
regards, xuron