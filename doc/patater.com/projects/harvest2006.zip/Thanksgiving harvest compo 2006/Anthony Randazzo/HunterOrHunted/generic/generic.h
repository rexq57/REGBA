#define playSound ((PlaySampleSoundCommand*)((uint32)(IPC) + sizeof(TransferRegion)))

enum msg
{ 
  LIGHT_ON,
  LIGHT_OFF,
  CLOCK,
  LED_ON,
  LED_SLOW_FLASH,
  LED_FAST_FLASH,
  PLAY_ONCE
 
}Messages;

struct PlaySampleSoundCommand
{
  int channel;
  int frequency;
  void* data;
  int length;
  int volume;
  int depth;
};


