#include <nds.h>
#include <stdlib.h>
#include "../../generic/generic.h"
//---------------------------------------------------------------------------------
void startSound(int sampleRate, const void* data, u32 bytes, u8 channel, u8 vol,  u8 pan, u8 format) {
//---------------------------------------------------------------------------------
	SCHANNEL_TIMER(channel)  = SOUND_FREQ(sampleRate);
	SCHANNEL_SOURCE(channel) = (u32)data;
	SCHANNEL_LENGTH(channel) = bytes >> 2 ;
	SCHANNEL_CR(channel)     = SCHANNEL_ENABLE | SOUND_ONE_SHOT | SOUND_VOL(vol) | SOUND_PAN(pan) | (format==1?SOUND_8BIT:SOUND_16BIT);
}


//---------------------------------------------------------------------------------
s32 getFreeSoundChannel() {
//---------------------------------------------------------------------------------
	int i;
	for (i=0; i<16; i++) {
		if ( (SCHANNEL_CR(i) & SCHANNEL_ENABLE) == 0 ) return i;
	}
	return -1;
}

int vcount;
touchPosition first,tempPos;

//---------------------------------------------------------------------------------
void VcountHandler() {
//---------------------------------------------------------------------------------
	static int lastbut = -1;
	
	uint16 but=0, x=0, y=0, xpx=0, ypx=0, z1=0, z2=0;

	but = REG_KEYXY;

	if (!( (but ^ lastbut) & (1<<6))) {
 
		tempPos = touchReadXY();

		x = tempPos.x;
		y = tempPos.y;
		xpx = tempPos.px;
		ypx = tempPos.py;
		z1 = tempPos.z1;
		z2 = tempPos.z2;
		
	} else {
		lastbut = but;
		but |= (1 <<6);
	}

	if ( vcount == 80 ) {
		first = tempPos;
	} else {
		if (	abs( xpx - first.px) > 10 || abs( ypx - first.py) > 10 ||
				(but & ( 1<<6)) ) {

			but |= (1 <<6);
			lastbut = but;

		} else { 	
			IPC->mailBusy = 1;
			IPC->touchX			= x;
			IPC->touchY			= y;
			IPC->touchXpx		= xpx;
			IPC->touchYpx		= ypx;
			IPC->touchZ1		= z1;
			IPC->touchZ2		= z2;
			IPC->mailBusy = 0;
		}
	}
	IPC->buttons		= but;
	vcount ^= (80 ^ 130);
	SetYtrigger(vcount);

}

//---------------------------------------------------------------------------------
void VblankHandler(void) {
//---------------------------------------------------------------------------------

	u32 i;


	//sound code  :)
	TransferSound *snd = IPC->soundData;
	IPC->soundData = 0;

	if (0 != snd) {

		for (i=0; i<snd->count; i++) {
			s32 chan = getFreeSoundChannel();

			if (chan >= 0) {
				startSound(snd->data[i].rate, snd->data[i].data, snd->data[i].len, chan, snd->data[i].vol, snd->data[i].pan, snd->data[i].format);
			}
		}
	}

}


static void PlayOneShotSample(PlaySampleSoundCommand* ps)
{
  int channel = ps->channel;

  SCHANNEL_CR(channel) = 0; 
  SCHANNEL_TIMER(channel) = SOUND_FREQ(ps->frequency);
  SCHANNEL_SOURCE(channel) = (u32)ps->data;
  SCHANNEL_LENGTH(channel) = ps->length >> 2;  
  SCHANNEL_PAN(channel) = 100;
  SCHANNEL_CR(channel) = 
    SCHANNEL_ENABLE | 
    SOUND_ONE_SHOT | 
    ps->depth | 
    SOUND_PAN(64) |
    SOUND_VOL(ps->volume);
}


u8 GetRegister(int reg)
{
	while(REG_SPICNT & SPI_BUSY)
		swiDelay(1);
 
	REG_SPICNT = SPI_ENABLE | SPI_DEVICE_POWER | SPI_BAUD_1MHz | SPI_CONTINUOUS;
	REG_SPIDATA = reg | 0x80;
 
	while(REG_SPICNT & SPI_BUSY)
		swiDelay(1);
 
	REG_SPICNT = SPI_ENABLE | SPI_DEVICE_POWER | SPI_BAUD_1MHz;
	REG_SPIDATA = 0;
 
	while(REG_SPICNT & SPI_BUSY)
		swiDelay(1);
 
	return REG_SPIDATA & 0xff;
}
 
void SetRegister(int reg, int control)
{
	while(REG_SPICNT & SPI_BUSY)
		swiDelay(1);
 
	REG_SPICNT = SPI_ENABLE | SPI_DEVICE_POWER | SPI_BAUD_1MHz | SPI_CONTINUOUS;
	REG_SPIDATA = reg;
 
	while(REG_SPICNT & SPI_BUSY)
		swiDelay(1);
 
	REG_SPICNT = SPI_ENABLE | SPI_DEVICE_POWER | SPI_BAUD_1MHz;
	REG_SPIDATA = control;
}

void ResetControl(int control)
{
	control = GetRegister(0) & ~control;
 
	SetRegister(0, control&255);
}
void SetControl(int control)
{
	SetRegister(0, GetRegister(0) | control);
}
void SetLED(int led)
{
	switch(led)
	{
		/* LED on */
	case 1:
		ResetControl(0x10);
		break;
		/* LED off (long), on (short) */
	case 2:
		ResetControl(0x20);
		SetControl(0x10);
		break;
		/* LED off (short), on (short) */
	case 3:
		SetControl(0x30);
		break;
  case 4:
		ResetControl(0x20);
		SetControl(0x05);

		break;
	}
}

void arm7Fifo()
{
  uint8 ct[sizeof(IPC->curtime)];
  u32 msg = REG_IPC_FIFO_RX;
  u32 i = 0;
	switch(msg)
  {
    
    case CLOCK:
      rtcGetTime((uint8 *)ct);
	    BCDToInteger((uint8 *)&(ct[1]), 7);
      for(i=0; i<sizeof(ct); i++) 
		    IPC->curtime[i] = ct[i];
    break;
    case LED_ON:
      SetLED(1);
    break;
    case LED_SLOW_FLASH:
      SetLED(2);
    break;
    case LED_FAST_FLASH:  
      SetLED(3);
    break;
    case LIGHT_ON:
      writePowerManagement(PM_CONTROL_REG,readPowerManagement(PM_CONTROL_REG) | PM_BACKLIGHT_TOP |  PM_BACKLIGHT_BOTTOM);
    break;
    case LIGHT_OFF:
      writePowerManagement(PM_CONTROL_REG,readPowerManagement(PM_CONTROL_REG) & ~( PM_BACKLIGHT_TOP |  PM_BACKLIGHT_BOTTOM)& 255);

    break;

    case PLAY_ONCE:
      PlaySampleSoundCommand* ps = playSound;
      PlayOneShotSample(ps);
    break;
  } 
}

//---------------------------------------------------------------------------------
int main(int argc, char ** argv) {
//---------------------------------------------------------------------------------

	// Reset the clock if needed
	rtcReset();
  REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_SEND_CLEAR; // enable & prepare fifo asap
	//enable sound
	powerON(POWER_SOUND);
	SOUND_CR = SOUND_ENABLE | SOUND_VOL(0x7F);
	IPC->soundData = 0;

	irqInit();
	irqSet(IRQ_VBLANK, VblankHandler);


	SetYtrigger(80);
	vcount = 80;
	irqSet(IRQ_VCOUNT, VcountHandler);
	irqEnable(IRQ_VBLANK);
  irqEnable(IRQ_VCOUNT);
  

  irqSet(IRQ_FIFO_NOT_EMPTY,arm7Fifo); // set up fifo irq
  irqEnable(IRQ_FIFO_NOT_EMPTY);
  REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_RECV_IRQ;
	// Keep the ARM7 idle
  while (1) swiWaitForVBlank();
}


