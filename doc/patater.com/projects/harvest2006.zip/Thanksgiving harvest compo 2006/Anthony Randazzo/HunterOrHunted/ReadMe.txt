Hunter or Hunted (c)2006 Knight0fDragon
Designed for Thanksgiving Contest @ http://www.patatersoft.info/harvestcompo2006.html


Rules:
As turkey, find your mate while avoiding hunters
As hunter, kill all turkeys

Card Types:
FAT Cards, include nds binary and data folder
FLASH Cards, include only nds binary

Controls

DPAD:  moves player on bottom screen
A:
  as turkey, gobbles to find mate
  as hunter, shoot arrows
R:
  swap players control


Benefits of turkeys
They can see all around them
When there mate gobbles, a location indicator is shown
on the screen to find their mate.

Flaws of turkeys
Can not attack

Benefits of hunters
Can attack and kill turkeys

Flaws
can only see in front of them


Screens

Top Screen: AI friend
Bottom Screen: Player 