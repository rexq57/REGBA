//FileName: AIClass.cpp
//Date Modified 05 May 2005
//Version: 3.0
//Team: AI
//Author: Anthony Randazzo
//Purpose: Source File to Implement the AI

#include "AIClass.h"

using namespace std;

//Purpose:Constructs the AI class
//Input:  None
//Output: None 
AIClass::AIClass()
{
  deltaCOL[AI_NORTH] = 0;
  deltaROW[AI_NORTH] =  -1;
  
  deltaCOL[AI_EAST] = 1; 
  deltaROW[AI_EAST] =  0;
  
  deltaCOL[AI_SOUTH] = 0;
  deltaROW[AI_SOUTH] = 1;
  
  deltaCOL[AI_WEST] =  -1;
  deltaROW[AI_WEST] =  0;
  
  deltaCOL[AI_NORTHEAST] = 1;
  deltaROW[AI_NORTHEAST] = -1;

  deltaCOL[AI_NORTHWEST] = -1;
  deltaROW[AI_NORTHWEST] = -1;

  deltaCOL[AI_SOUTHEAST] = 1;
  deltaROW[AI_SOUTHEAST] = 1;

  deltaCOL[AI_SOUTHWEST] = -1;
  deltaROW[AI_SOUTHWEST] = 1;
  
  lastKeyInput = KEY_DOWN;
}
AIClass::~AIClass()
{
}

/*
void AIClass::getOppenentPathToMe(posit oppsPos,int oppsID, int myID, int tick )
{
  //int s;
  //posit* temp = new posit[NumOfItems];
  //temp[0] = AIPath[myID][tick];
  //s = AStarAlgPath(oppsPos, oppsID, temp, Map);
  TurkeyData x1;
  TurkeyData x2;
  x1.posX = oppsPos.posX;
  x1.posY = oppsPos.posY;
  x2.posX = AIPath[myID][tick].posX;
  x2.posY = AIPath[myID][tick].posY;
  ShortestPath(x1,x2,AIPathToMe[oppsID],AIPathToMeLength[oppsID], oppsID, tick);
  //AIPathLength[oppsID] = tick;
}

void AIClass::setMap(int x,int y,int status)
{
  
   MapList[x + y * MapWidth].status = status;

}
*/
//Purpose: Uses the A* Algorithm to find the best path
//Input:   Current position of the AI, position of desired item, map
//Output:  Command for Input(direction) 
void AIClass::ShortestPath(TurkeyData &myPosition,TurkeyData &targetPosition, posit* pathTaken, int &pathLength, int player, int tick)
{  
  
  
  node smallestNode;
  node currentDirection;
  posit targetDirection;
  int tempCol = 0;
  int tempRow = 0;
  int MapOpenCounter = 0;
  int numberStepsTaken = 0;
  bool noneOpen = false;
  int direction = 0;
//  long filePos = 0;
  posit tempDir;
  posit* tempPathTaken;
  tempPathTaken = new posit[tick];
  int spot = 0;
  int oldSpot = 0;
  bool found = false;
  //Sets the every node on the Item array score to highest possible value
  //This is used later on so that the snake doesn't accidently go down an unwanted path
  //for (int counter = 0; counter < Item; counter++)
   // ItemArray[counter].score = MAXINT;
 
  
  //Sets the smallestNodes score to highest possible value
  //This is used later on so that every other node is < smallestNode at start
  smallestNode.score     = MAXUINT;
  
  //Sets the every node on the map's score to highest possible value
  //This is used later on so that the snake doesn't accidently go down an unwanted path
  for (u32 i = 0; i < MapHeight * MapWidth; i++)
  {
    MapList[i].score = MAXUINT;
    MapList[i].dir = AI_NO_DIR;
    
  }


  //Initalize Current direction with the path of the snake
  currentDirection.Col         = ((myPosition.posX>>4) - myPosition.mapX>>1) + 1;
  currentDirection.Row         = ((myPosition.posY>>4) - myPosition.mapY>>1) + 1;
  currentDirection.preCol      = ((myPosition.posX>>4) - myPosition.mapX>>1) + 1;
  currentDirection.preRow      = ((myPosition.posY>>4) - myPosition.mapY>>1) + 1;
  currentDirection.startcost = 0;
  currentDirection.heuristic = 0;
  currentDirection.score = currentDirection.startcost + currentDirection.heuristic;
  currentDirection.status = AI_OPENED;  //End init
  currentDirection.dir = AI_NO_DIR;
  
  targetDirection.Col         = (targetPosition.posX>>4)+1;
  targetDirection.Row         = (targetPosition.posY>>4)+1 ;
  
  
  nodeEqual(MapList[currentDirection.Col + currentDirection.Row * MapWidth],currentDirection);

  //MapList[currentDirection.Col + currentDirection.Row * MapWidth].status =(AIMAP) 9;
  MapList[targetDirection.Col + targetDirection.Row * MapWidth].status =AI_GOAL;
  
  //while(1)
  //  Debug();
  //while(1)Debug(); 
  MapOpenCounter++;//increase number of OPENS nodes
  if (
    (currentDirection.Col == (targetDirection.Col)) 
    &&
	    
    (currentDirection.Row == (targetDirection.Row))
    )
  { 
      pathLength = tick;
      delete[] tempPathTaken;
      pathTaken[0].Col = (myPosition.posX>>4) - myPosition.mapX>>1;
      pathTaken[0].Row = (myPosition.posY>>4) - myPosition.mapY>>1;
      return;
  }   
  //loop while there is an OPENS node
  
  
  int countTerms = 0;
  while(!noneOpen)
  {

    if(countTerms >= tick)
  	  break;
    countTerms++;
    //If node is at the destination
	
    if (
    (currentDirection.Col == (targetDirection.Col)) 
    &&
	    
    (currentDirection.Row == (targetDirection.Row))
    )
    {
      found = true;
      break;
    }
    
	  MapList[currentDirection.Col + currentDirection.Row * MapWidth].status = AI_CLOSED;
    currentDirection.status = AI_CLOSED; 
    MapOpenCounter--;
    direction = 9;
 
    for (int pathchecking = 0; pathchecking < 8; pathchecking++)
    {
      direction = pathchecking;
      //Debug();
      tempRow = (deltaROW[pathchecking]);
      tempCol = (deltaCOL[pathchecking]);
      if (
           (currentDirection.Col + tempCol >= MapWidth - 1) ||
           (currentDirection.Col + tempCol < 0) ||
           (currentDirection.Row + tempRow >= MapHeight - 1) ||
           (currentDirection.Row + tempRow < 0) 
          )
          continue;
      spot = (currentDirection.Col + tempCol) + (currentDirection.Row  + tempRow) * MapWidth;
      oldSpot =  (currentDirection.Col) + (currentDirection.Row) * MapWidth;
      if(MapList[spot].status == AI_GOAL)
        break;
      if
      (
       
       MapList[spot].status == AI_ENEMY ||
       MapList[spot].status == AI_OBSTACLE ||
       MapList[spot].status == AI_OPENED ||
       MapList[spot].status == AI_CLOSED ||
       MapList[spot].status == AI_FRIEND ||
       (
         //(pathchecking == AI_NORTHEAST) && 
         (
          (MapList[spot - 1].status == AI_OBSTACLE) || (MapList[spot + MapWidth].status == AI_OBSTACLE) || (MapList[spot + 2 *MapWidth].status == AI_OBSTACLE)
         )
       )||
       ( 
         //(pathchecking == AI_NORTHWEST) && 
         (
          (MapList[spot + 1].status == AI_OBSTACLE) || (MapList[spot + MapWidth].status == AI_OBSTACLE)
         )
       )||
       (
         //(pathchecking == AI_SOUTHEAST) && 
         (
          (MapList[spot + 1].status == AI_OBSTACLE) || (MapList[spot - MapWidth].status == AI_OBSTACLE)
         )
       )||
       (
         //(pathchecking == AI_SOUTHWEST) && 
         (
          (MapList[spot - 1].status == AI_OBSTACLE) || (MapList[spot - MapWidth].status == AI_OBSTACLE)
         )
       )||
       (
         //(pathchecking == AI_NORTHEAST) && 
         (
          (MapList[spot - 1].status == AI_OBSTACLE) || (MapList[spot + 1 + MapWidth].status == AI_OBSTACLE) || (MapList[spot + 2 *MapWidth].status == AI_OBSTACLE)
         )
       )||
       ( 
         //(pathchecking == AI_NORTHWEST) && 
         (
          (MapList[spot + 1].status == AI_OBSTACLE) || (MapList[spot + 1 + MapWidth].status == AI_OBSTACLE)
         )
       )||
       (
         //(pathchecking == AI_SOUTHEAST) && 
         (
          (MapList[spot + 1].status == AI_OBSTACLE) || (MapList[spot - 1 - MapWidth].status == AI_OBSTACLE)
         )
       )||
       (
         //(pathchecking == AI_SOUTHWEST) && 
         (
          (MapList[spot - 1].status == AI_OBSTACLE) || (MapList[spot - 1 - MapWidth].status == AI_OBSTACLE)
         )
       )
       
      )
        continue;
      
      MapList[spot].Col       
        = currentDirection.Col + tempCol;

      MapList[spot].Row       
        = currentDirection.Row + tempRow;

      MapList[spot].preCol    
        = currentDirection.Col;

      MapList[spot].preRow    
        = currentDirection.Row;
      if(pathchecking & 1)
      MapList[spot].startcost 
        =  MapList[oldSpot].startcost + 6;
      else
      MapList[spot].startcost 
        =  MapList[oldSpot].startcost + 2;
      
      
      MapList[spot].heuristic 
        = heuristic((targetDirection.Col),(targetDirection.Row),currentDirection.Col + tempCol, currentDirection.Row + tempRow);

      MapList[spot].score  =     
       MapList[spot].heuristic 
        + MapList[spot].startcost;

      MapList[spot].status    
        = AI_OPENED;
      
      MapList[spot].dir    
        = (AIDIR)direction;        
      MapOpenCounter++;
	  

    }
    
    
    if(MapList[spot].status == AI_GOAL)
        break;
      
    //Reset smallestNode
    smallestNode.Col = 0;
    smallestNode.Row = 0;
    smallestNode.preCol = 0;
    smallestNode.preRow = 0;
    smallestNode.startcost = 0;
    smallestNode.heuristic = 0;
    smallestNode.score = MAXUINT;
    smallestNode.status = AI_NONE;
    noneOpen = true;
        

	  for (u32 i = 0; i < MapWidth * MapHeight;i++)
    {
      if (MapList[i].status == AI_OPENED)
      {
        if(MapList[i].score < smallestNode.score)
        { 
          nodeEqual(smallestNode,MapList[i]);
          i = 0;
          noneOpen = false; 
        }
          
        //If the scores are equal, then look to see which is 
        //closer in Taxi Cab metric
        if((MapList[i].score == smallestNode.score) &&
          (MapList[i].heuristic < smallestNode.heuristic))
        {
            nodeEqual(smallestNode,MapList[i]);
            i = 0;
            noneOpen = false;
        }
      }
	
    }
//    while(1)
    //after here sort and make smallest startcost the next current node
    nodeEqual(currentDirection, smallestNode );
  }
   
  if ((countTerms >= tick) && (!found))
  {
    pathLength = tick;
    delete[] tempPathTaken;
    pathTaken[0].Col = (myPosition.posX>>4) - myPosition.mapX>>1;
    pathTaken[0].Row = (myPosition.posY>>4) - myPosition.mapY>>1;
    
    return; 
      
  }
  
 
// all nodes closed
  tempDir.Col = currentDirection.Col;
  tempDir.Row = currentDirection.Row;
  
  //walks back to count the number of steps taken
  while (currentDirection.startcost > (0))
  {
    
    currentDirection = MapList[currentDirection.preCol + currentDirection.preRow * MapWidth];
    tempPathTaken[numberStepsTaken].Col = currentDirection.Col;
    tempPathTaken[numberStepsTaken].Row = currentDirection.Row;
    tempPathTaken[numberStepsTaken].dir = currentDirection.dir;
    
    numberStepsTaken++; 
    
  }
  
  //add 1 to the pathlength to include spot agent is standing
  //save the path that is took
  pathLength = numberStepsTaken + 1;
  for (int count = numberStepsTaken - 2; count > -1; count--)
  { 
    pathTaken[numberStepsTaken - 2 - count].Col = tempPathTaken[count].Col;
    pathTaken[numberStepsTaken - 2 - count].Row = tempPathTaken[count].Row;
    pathTaken[numberStepsTaken - 2 - count].dir = tempPathTaken[count].dir;
    
  }
  
  
  pathTaken[numberStepsTaken ].Col = (targetDirection.Col);
  pathTaken[numberStepsTaken].Row = (targetDirection.Row);
  delete[] tempPathTaken;
  MapList[0].status = (AIMAP)(pathTaken[0].Col / 10);
  MapList[1].status = (AIMAP)(pathTaken[0].Col % 10);
  MapList[2].status = (AIMAP)10;
  
  MapList[16].status = (AIMAP)(pathTaken[0].Row / 10);
  MapList[17].status = (AIMAP)(pathTaken[0].Row % 10);
  MapList[18].status = (AIMAP)10;
  
  //while(1)
  //for(int i = 0; i < 30; i++)
  //Debug();   
  return;
}






//Purpose: Sets node1 = to node2
//Input:   node, node, Item desired
//Output:  NONE
inline void AIClass::nodeEqual(node &node1, node &node2)
{
  node1.Col         = node2.Col;
  node1.Row         = node2.Row;
  node1.preCol      = node2.preCol;
  node1.preRow      = node2.preRow;
  node1.startcost   = node2.startcost;
  node1.dir         = node2.dir;
  node1.heuristic   = node2.heuristic;
  node1.score       = node2.score;// - node2.heuristic 
  node1.status      = node2.status ;
}

void AIClass::setMapSize(int width,int height)
{
  MapWidth = width;
  MapHeight = height;
  MapList = new node[MapHeight * MapWidth];
  

}


bool AIClass::checkProjectile(TurkeyData turk)
{
  u32 x = 0,y = 0,dx = 0,dy = 0;
  switch(turk.projectileDeg)
  {
    case DEGDOWN:
      dx = 0;
      dy = 1;
    break;
    case DEGDOWNLEFT:
      dx = -1;
      dy = 1;
    break;
    case DEGLEFT:
      dx = -1;
      dy = 0;
    break;
    case DEGUPLEFT:
      dx = -1;
      dy = -1;
    break;
    case DEGUP:
      dx = 0;
      dy = -1;
    break;
    case DEGUPRIGHT:
      dx = 1;
      dy = -1;
    break;
    case DEGRIGHT:
      dx = 1;
      dy = 0;
    break;
    case DEGDOWNRIGHT:
      dx = 1;
      dy = 1;
    break;
    case FLIP:
    break;
  }
  
  x = (124) >> 4;
  y = (92) >> 4;
  while(1)
  { 
    if (MapList[x + y * MapWidth].status == AI_ENEMY)
      return true;
    if (MapList[x + y * MapWidth].status == AI_OBSTACLE)
      return false;
      
    x+=dx;
    y+=dy;
    if(x >= MapWidth)
      break;
    if(x < 0)
      break;
    if(y >= MapHeight)
      break;
    if(y < 0)
      break;
  }
  return false;
}



int AIClass::getInput(TurkeyData &turkeyz)
{
  
  int  pathLength = 0;
  int keyInput = 0;
  u32 x = 0,y = 0;
  u32 lowScore = MAXUINT;
  int temp = 0;
  bool coverSafe;
  u32 lowSpot = 0;
  TurkeyData bestTurkey;
  int spotX = 0;
  int spotY = 0;
  
  path[0].Col = ((turkeyz.posX >> 4) - turkeyz.mapX>>1);
  path[0].Row = ((turkeyz.posY >> 4) - turkeyz.mapY>>1);
  path[0].dir = AI_NO_DIR;
  
  if(turkeyz.type == TURKEY)
  {
    
    if(enemyCnt > 0)
    {
    
      for(int t = 0; t < 12; t++)
      {
        lowScore = MAXUINT;
        
        if(coverCnt <= 0)
        {
          
          for(u32 i = 0; i < enemyCnt;i++)
          {
            
            if((u32)
                ABS((enemyArray[i].Col - (path[0].Col)) + 
                         (enemyArray[i].Row - (path[0].Row))
                    ) < lowScore)
            {
              bestTurkey.posX = (MapWidth - 1 - enemyArray[i].Col) << 4;
              bestTurkey.posY = (MapHeight - 1 - enemyArray[i].Row) << 4;
              lowScore = ABS(
                (enemyArray[i].Col - (path[0].Col)) + 
                (enemyArray[i].Row - (path[0].Row)));
              coverSafe = false;
              u32 j = lowSpot; 
              while(j < coverCnt - 1)
              {
                coverArray[j].Col = coverArray[j+1].Col;
                coverArray[j].Row = coverArray[j+1].Row;
                j++;
              }
            }
          }
          
          break;
          
        }
        
        
        for(u32 i = 0; i < coverCnt;i++)
        {
          if((u32)ABS(((coverArray[i].Col - path[0].Col) + 
            (coverArray[i].Row - path[0].Row)))< lowScore)
          {
            bestTurkey.posX = coverArray[i].Col << 4;
            bestTurkey.posY = coverArray[i].Row << 4;
            lowScore = ABS((coverArray[i].Col - path[0].Col) + 
              (coverArray[i].Row - path[0].Row));
            lowSpot = i;
          }
        }
        coverSafe = true;
        for(u32 i = 0; i < enemyCnt;i++)
        {
          if(ABS((enemyArray[i].Col - (bestTurkey.posX >> 4)) + 
            (enemyArray[i].Row - (bestTurkey.posY >> 4))) < lowScore)
          {
          
            bestTurkey.posX = (MapWidth - 1 - friendArray[i].Col) << 4;
            bestTurkey.posY = (MapHeight - 1 - friendArray[i].Row) << 4;
            lowScore = ABS((friendArray[i].Col - (bestTurkey.posX>>4)) + 
              (friendArray[i].Row - (bestTurkey.posY>>4)));
            coverSafe = false;
            u32 j= lowSpot;
            while(j < coverCnt - 1)
            {
              coverArray[j].Col = coverArray[j+1].Col;
              coverArray[j].Row = coverArray[j+1].Row;
              j++;
            }
            coverCnt--;
          }
          
        }
        if(coverSafe)
          break;
          
      }
    
    }
    
    if(enemyCnt <= 0)
    {
      
      for(u32 i = 0; i < friendCnt;i++)
      {
        
        if((u32)ABS(((friendArray[i].Col - path[0].Col) + 
          (friendArray[i].Row - path[0].Row))) < lowScore)
        {
          bestTurkey.posX = friendArray[i].Col << 4;
          bestTurkey.posY = friendArray[i].Row << 4;
          lowScore = ABS((friendArray[i].Col - path[0].Col) + 
            (friendArray[i].Row - path[0].Row));
          lowSpot = i;
          
        }
      }
    }
  }
  
  if(turkeyz.type == NATIVE)
  {
    
    for(u32 i = 0; i < enemyCnt;i++)
    {
      
      if(ABS((u32)((enemyArray[i].Col - path[0].Col) + 
         (enemyArray[i].Row - path[0].Row)))< lowScore)
      {
        bestTurkey.posX = enemyArray[i].Col << 4;
        bestTurkey.posY = enemyArray[i].Row << 4;
        lowScore = ABS((enemyArray[i].Col - path[0].Col) + 
         (enemyArray[i].Row - path[0].Row));
      }
    }
    for(u32 i = 0; i < friendCnt;i++)
    {
      if(
         ABS(
             (friendArray[i].Col - (bestTurkey.posX>>4)) + 
             (friendArray[i].Row - (bestTurkey.posY>>4))
            ) < lowScore)
      {
      
        bestTurkey.posX = (MapWidth - 1 - friendArray[i].Col) << 4;
        bestTurkey.posY = (MapHeight - 1 - friendArray[i].Row) << 4;
        lowScore = ABS((friendArray[i].Col - (bestTurkey.posX>>4)) + 
         (friendArray[i].Row - (bestTurkey.posY>>4)));
      }
    }
    
  }
  
  //MapList[(bestTurkey.posX  >> 3) + (bestTurkey.posY>>3) * MapWidth].status = (AIMAP)10;
  //MapList[0].status = (AIMAP)10;
  
 
  path[0].dir= AI_NO_DIR;
  if(lowScore < 120)  
    ShortestPath(turkeyz,bestTurkey, path, pathLength, 1, 30);
    
  
  switch(path[0].dir)
  {
    case AI_EAST:
      keyInput = KEY_RIGHT;
    break;
    case AI_WEST:
      keyInput = KEY_LEFT;
    break;
    case AI_SOUTH:
      keyInput = KEY_DOWN;
    break;
    case AI_NORTH:
      keyInput = KEY_UP;
    break;
    case AI_SOUTHEAST : 
      keyInput = KEY_RIGHT | KEY_DOWN;
    break;
    case AI_NORTHEAST:
      keyInput = KEY_RIGHT | KEY_UP;
    break;
    case AI_SOUTHWEST:
      keyInput = KEY_LEFT | KEY_DOWN;
    break;
    case AI_NORTHWEST:
      keyInput = KEY_LEFT | KEY_UP;
    break;
    case AI_NO_DIR:
    {
      if((rand() & 255) >= 128)
      {
        temp = lastKeyInput + 1;
        if(temp > (7 << 6)) temp = 0;
      }
      else
      {
        temp = lastKeyInput - 1;
        if(temp < 0) temp = (7<<6);
      }
      lastKeyInput = temp;
      //return 0 ;
      switch(temp>>4)
      {
        case AI_EAST:
          keyInput = KEY_RIGHT;
        break;
        case AI_WEST:
          keyInput = KEY_LEFT;
        break;
        case AI_SOUTH:
          keyInput = KEY_DOWN;
        break;
        case AI_NORTH:
          keyInput = KEY_UP;
        break;
        case AI_SOUTHEAST : 
          keyInput = KEY_RIGHT | KEY_DOWN;
        break;
        case AI_NORTHEAST:
          keyInput = KEY_RIGHT | KEY_UP;
        break;
        case AI_SOUTHWEST:
          keyInput = KEY_LEFT | KEY_DOWN;
        break;
        case AI_NORTHWEST:
          keyInput = KEY_LEFT | KEY_UP;
        break;
        case AI_NO_DIR:
        {
          //return 0 ;
      
        }
        break;
      }   
    }
    break;
  } 
  
   
    
  if((turkeyz.type == NATIVE) && (checkProjectile(turkeyz)))
    keyInput |= KEY_A; 
 
  return keyInput;
}

void AIClass::Debug()
{
  u16* bgTile0 = (u16*)CHAR_BASE_BLOCK(9);
  u16* bgMap0  = (u16*)SCREEN_BASE_BLOCK(0);

  u32 x = 0;
  u32 y = 0;
  u32 length;
  videoSetMode   (MODE_5_2D | DISPLAY_BG3_ACTIVE);	//not using the main screen
	
  
  
  dmaCopy(fps,bgTile0,640);
  x = 0; y = 0;
  for(u32 i = 0; i < MapWidth * MapHeight;i++)
  {
    if((MapList[x + y * MapWidth].score >>4) > 9)  
    bgMap0[x + (y * 64)] = 9;
    else
    bgMap0[x + (y * 64)] = MapList[x + y * MapWidth].score >>4;
    
    bgMap0[x + (y * 64)] = MapList[x + y * MapWidth].status;
    
    x++;
    if (x >= MapWidth)
    {
      y++;
      x = 0;
    }
  }
  
}
/*
void AIClass::getBestItemPath(posit AIposition[], vector<item> Item[])
{
  int count = 0;
  int closestItem = 0;
  int closestLength = 0;
  int ItemLength = -1;
  int ItemValue;
  posit ItemPath[TOTAL_PATH_LENGTH];
  int totalPoints;
  //clears out all item paths
  //SecureZeroMemory(ItemPath,30720 );

  snakeLink x1;
  snakeLink x2;
  
  for(count = 0; count < NUM_OF_AI; count++)
  {
    x1.Col = AIposition[count].Col;
    x1.Row = AIposition[count].Row  - 1;
    x1.fromDirection = AIposition[count].direction;
  
	//change this if more then 2 players
    if (chase[count])         
    {
      x2.Col = AIposition[(count  + 1) % NUM_OF_AI].Col;
      x2.Row = AIposition[(count + 1) % NUM_OF_AI].Row - 1;
      x2.fromDirection = 1;
      closestItem = 0;
    }    
    else
    {
      int smallest = MAXINT;
      for (unsigned int itemCount = 0; itemCount < Item[count].size(); itemCount++)
      {
        if (itemCount >= Item[count].size())
            break;
		  ItemLength = 0;
		  ItemValue = 0;
		//Calculate the shortest path using heuristic
      
        x2.Col = Item[count].at(itemCount).x;
        x2.Row = Item[count].at(itemCount).y - 1;
        x2.fromDirection = Item[count].at(itemCount).type;
      
        //ItemLength = heuristic(x1.Col,x1.Row,x2.Col,x2.Row);
        ShortestPath(x1,x2,ItemPath,ItemLength,count,ItemLength); 
		    totalPoints = returnItemPointValue(x2.fromDirection,snakeLength[count]);

		  //if the item im searching around == the item x2 is at then continue loop

		  // if the item at itemCount is 2 spaces away, increase its value
        for (unsigned int itemCount2 = 0; itemCount2 < Item[count].size(); itemCount2++)
        {
		      if (itemCount2 >= Item[count].size())
            break;
          if(Item[count].at(itemCount2).x >=  x2.Col - 2 &&  
		         Item[count].at(itemCount2).x <=  x2.Col + 2 && 
		         Item[count].at(itemCount2).y-1 >=  x2.Row - 2 &&
		         Item[count].at(itemCount2).y-1 <=  x2.Row + 2)
          {
            ItemValue++;
            totalPoints += returnItemPointValue(x2.fromDirection,snakeLength[count]);

          }

        }
      //determine Item's worth heuristic
      // theory  length to item * score of region * # of items found / Length
		  if (smallest > ItemLength - (totalPoints * ItemValue) / ItemLength)
		  {
		  	smallest = ItemLength - (totalPoints * ItemValue)/ ItemLength;
		  	closestItem = itemCount;
        closestLength = ItemLength;
		  }
      else if (smallest == ItemLength - (totalPoints * ItemValue) / ItemLength)
      {
       if (ItemLength < closestLength)
       {
         closestItem = itemCount;
         closestLength = ItemLength;
       }
      }
	  } 
    
 
   
      //closestItem = //ShortestItemLength(ItemLength,ItemValue);
      x2.Col = Item[count].at(closestItem).x;
	    x2.Row = Item[count].at(closestItem).y - 1;
	    x2.fromDirection =  Item[count].at(closestItem).type;

    }
    for (u16 zero = 0; zero < TOTAL_PATH_LENGTH; zero++) 
	{
      ItemPath[zero].Col = 0;
	  ItemPath[zero].Row = 0;
	  ItemPath[zero].direction = 0;
	}
    #ifdef DEBUG
      brain.clear(); 
    #endif
    ShortestPath(x1,x2,ItemPath,ItemLength,count);  


    AIPathLength[count] = ItemLength;
    for(int count3 = 0; (int)count3 < AIPathLength[count]; count3++)
      AIPath[count][count3] = ItemPath[count3];
 	  
    //getOppenentPathToMe(AIposition[(count + 1) % NUM_OF_AI], 1,  0, 0);
    setMove(count, AIposition[count].direction);
  }

}

 
void AIClass::testPath(posit AIposition[],vector<item> Item[])
{  
  snakeLink x1;
  snakeLink x2;
  int count = 0;
//  int moveChange = 0;
  bool noCollision = false;
  vector<item> changes[NUM_OF_AI];
  item tempWall;
 
//  int tickCount = 0;
  


//
  int spotInPath = 0;// keeps track of what "tick" we are in.
  //while none of the AI collide
  while(!noCollision)
  {
  
    noCollision = true;
    //this is used to loop through the number of AI players, after the first AI

    //grabs the "What if I am the target" path 
    for (count = 0; count < 2; count++)
    {
      getOppenentPathToMe( 
	                         AIposition[ (count + 1) % NUM_OF_AI ],
	                         (count + 1) % NUM_OF_AI,
					                 count, 
					                 -1);
    }

    if ((AIPathToMeLength[0] < spotInPath) ||
        (AIPathToMeLength[1] < spotInPath) ||
        (AIPathToMeLength[0] > 10) ||
        (AIPathToMeLength[1] > 10))
          break;

       //Checks if the 2 players end up on the same spot
    if(
        (AIPath[0][spotInPath].Col == AIPathToMe[1][spotInPath].Col &&
        AIPath[0][spotInPath].Row == AIPathToMe[1][spotInPath].Row) ||
		    (AIPath[1][spotInPath].Col == AIPathToMe[0][spotInPath].Col &&
        AIPath[1][spotInPath].Row == AIPathToMe[0][spotInPath].Row) 
      )
    {
      //1st Player Change
	  //determines if a chase should be persued 
      if (!chase[0])
      {
         noCollision = false;
       
        Map[0]
           [AIPath[0][spotInPath].Col]
           [AIPath[0][spotInPath].Row]
           = '0';

		     tempWall.x = AIPath[0][spotInPath].Col;
         tempWall.y = AIPath[0][spotInPath].Row;
		     tempWall.type = ' ';
	       changes[0].push_back(tempWall);
      }
  
      //getBestItemPath(AIposition,Item);
      //End 1st
      
       //2nd Player Change
      if (!chase[1])
      {
        noCollision = false;
       
        Map[1][AIPath[1][spotInPath].Col][AIPath[1][spotInPath].Row] = '0';
		    tempWall.x = AIPath[1][spotInPath].Col;
        tempWall.y = AIPath[1][spotInPath].Row;
	     	tempWall.type = ' ';
	    	changes[1].push_back(tempWall);
      }
      if(chase[0])
      { 
        x1.Col = AIPath[0][0].Col;
        x1.Row = AIPath[0][0].Row;
        x1.fromDirection = AIPath[0][0].direction;
        x2.Col = AIPath[1][0].Col;
        x2.Row = AIPath[1][0].Row;
        x2.fromDirection = AIPath[1][0].direction;
        ShortestPath(x1,x2,AIPath[0],AIPathLength[0],0);
      }
      if(chase[1])
      {
        x1.Col = AIPath[0][0].Col;
        x1.Row = AIPath[0][0].Row;
        x1.fromDirection = AIPath[0][0].direction;
        x2.Col = AIPath[1][0].Col;
        x2.Row = AIPath[1][0].Row;
        x2.fromDirection = AIPath[1][0].direction;
        ShortestPath(x1,x2,AIPath[1],AIPathLength[1],1);
      }
      getBestItemPath(AIposition,Item);
      //End 2nd

      //Resets all loops
      spotInPath = 0;
    }
    spotInPath++;
  }

//undoes changes
  for (unsigned int temp = 0; temp < changes[0].size(); temp++)
  {
    if (temp >= changes[0].size())
      break;
	  Map[0][changes[0].at(temp).x][changes[0].at(temp).y]= changes[0].at(temp).type;
  }

  for (unsigned int temp = 0; temp < changes[1].size(); temp++)
  {
    if (temp >= changes[1].size())
      break;
	  Map[1][changes[1].at(temp).x][changes[1].at(temp).y]= changes[1].at(temp).type;
  }

}

//Purpose: Used to calculate the best possible path
//Input:   Current position of the AI, possition of desired item, map
//Output:  Command for Input(direction) 
void AIClass::getPath(posit AIposition[], vector<item> Item[] , vector<item> Bad[], Maze maze[64][64], int scores[], int lengthy[])

{ 
  unsigned int countTemp = 0;
	snakeLength[0] = lengthy[0];
	snakeLength[1] = lengthy[1];
  
  char blocksType = 0;
  if (!Item[0].size() || !Item[0].size())
    return;
  
  for(countTemp = 0; countTemp < NUM_OF_AI;countTemp++)
    score[countTemp] = scores[countTemp];
  //change this for more players
  if (score[0] > score[1])
  {
    chase[0] = true;
    chase[1] = false;
  }
  else if(score[0] < score[1])
  {
    chase[1] = true;
    chase[0] = false;
  
  }
  else
  {
    chase[0] = false;
    chase[1] = false;
  }
  ///
  //fopen(
  //check gate changes
  for(countTemp = 0; countTemp < gate.size(); countTemp++)
  {
    if (countTemp >= gate.size())
      break;
    int x = gate.at(countTemp).x;
    int y = gate.at(countTemp).y;
    switch(maze[y][x])
    {
      case DOOR1_ + _CLOSED:
      case DOOR2_ + _CLOSED:
      case DOOR3_ + _CLOSED:
      case DOOR_  + _CLOSED:
        blocksType = '0';
      break;

      case DOOR_ + _OPEN:
      case DOOR1_ + _OPEN  :
      case DOOR2_ + _OPEN:   
      case DOOR3_ + _OPEN:
        blocksType = ' ';
      break;
    }
    Map[0][x][y] = blocksType;
    Map[1][x][y] = blocksType;
  }
 //sets hazards to walls
  for(countTemp = 0; countTemp < Bad[0].size(); countTemp++)
  {
    blocksType = '0';
    if (countTemp >= Bad[0].size())
      break;
    Map[0][Bad[0].at(countTemp).x][Bad[0].at(countTemp).y - 1] = blocksType;

   }

  for(countTemp = 0; countTemp < Bad[1].size(); countTemp++)
  {
    blocksType = '0';
    if (countTemp >= Bad[1].size())
      break;
    Map[1][Bad[1].at(countTemp).x][Bad[1].at(countTemp).y - 1] = blocksType;
  }
  //end setting hazards to walls

  //end gate changes
 //fclose(pFile);
  //this here gets the AIs initial paths
  getBestItemPath(AIposition,Item);

  //int x = AIPath[0][0].Col;
  //This here is used to detect whether or not snakes collide
  testPath(AIposition,Item);
  
  

  //Sets the final move here and cleans up

  setMove(0, AIPath[0][0].direction);
  setMove(1, AIPath[1][0].direction);

  //sets hazards to air
  for(countTemp = 0; countTemp < Bad[0].size(); countTemp++)
  {
    blocksType = ' ';
    Map[0][Bad[0].at(countTemp).x][Bad[0].at(countTemp).y - 1] = blocksType;
   }

  for(countTemp = 0; countTemp < Bad[1].size(); countTemp++)
  {
    blocksType = ' ';
    Map[1][Bad[1].at(countTemp).x][Bad[1].at(countTemp).y - 1] = blocksType;
  } 
  //end setting hazards to air again
}


void AIClass::positEqual(posit a, posit b)
{
  a.Col    = b.Col;
  a.Row    = b.Col;
  a.direction = b. direction;
}


int AIClass::getMove(int AIPlayer)
{
  return AIMove[AIPlayer];
}

void AIClass::setMove(int AIPlayer, int moves)
{
  AIMove[AIPlayer] = moves;
}



int AIClass::returnItemPointValue(int enumNum, int lengths)
{

  switch(enumNum)
  {
    case EARN5_:    return(5);    break;
    case EARN10_:   return(10);   break;
    case EARN20_:   return(20);   break;
    case EARN25_:   return(25);   break;
    case EARN50_:   return(50);   break;
    case EARN100_:  return(100);  break;
    case EARN5xL_:  return(5  * lengths); break;
    case EARN10xL_: return(10 * lengths); break;
    case EARN20xL_: return(20 * lengths); break;
    
      //team 1 items
    case EARN5_ + 1:    return(5);    break;
    case EARN10_ + 1:   return(10);   break;
    case EARN20_ + 1:   return(20);   break;
    case EARN25_ + 1:   return(25);   break;
    case EARN50_ + 1:   return(50);   break;
    case EARN100_ + 1:  return(100);  break;
    case EARN5xL_ + 1:  return(5  * lengths); break;
    case EARN10xL_ + 1: return(10 * lengths); break;
    case EARN20xL_ + 1: return(20 * lengths); break;    
    // team 2 items
    
    case EARN5_ + 2:    return(5);    break;
    case EARN10_ + 2:   return(10);   break;
    case EARN20_ + 2:   return(20);   break;
    case EARN25_ + 2:   return(25);   break;
    case EARN50_ + 2:   return(50);   break;
    case EARN100_ + 2:  return(100);  break;
    case EARN5xL_ + 2:  return(5  * lengths); break;
    case EARN10xL_ + 2: return(10 * lengths); break;
    case EARN20xL_ + 2: return(20 * lengths); break;
    default: return 22;
  }
  
}
*/
