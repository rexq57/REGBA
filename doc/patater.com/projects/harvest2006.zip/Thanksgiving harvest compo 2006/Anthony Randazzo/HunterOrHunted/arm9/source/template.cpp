#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../generic/generic.h"
#include <gbfs.h>				// filesystem functions
#include <fat.h>
#include <sys/stat.h>
#include "AIClass.h"
#define SOUND_16BIT      (1<<29)
#define SOUND_8BIT       (0) 
#define MAIN 0
#define SUB 1
#define BOTH 2
#define ON true
#define OFF false
#define SPRITEGROUP 48
#define TURKEYSTART SPRITEGROUP * 0
#define NATIVESTART SPRITEGROUP * 1


AIClass* ai;

const GBFS_FILE*  data_gbfs;
extern FILE* fileIn(char*fileName,u32 &length);

extern FILE* fileIn(char*fileName);
#define TOTALMAPTILES 1048576
#define BUFFERSIZE 65536
#define TILEBASE0 9
#define MAPBASE0 0
#define TILEBASE1 9
#define MAPBASE1 2

#define SUBTILEBASE0 2
#define SUBMAPBASE0 0
#define SUBTILEBASE1 2
#define SUBMAPBASE1 2
#define PLAYERS 101
#define NUMBEROFAUDIO 2
int TURKEYNUM = PLAYERS;
TurkeyData turkey[PLAYERS];

u8 forest[TOTALMAPTILES];
u16* bgTile0 = (u16*)CHAR_BASE_BLOCK(TILEBASE0);
u16* bgMap0  = (u16*)SCREEN_BASE_BLOCK(MAPBASE0);

u16* bgTile1 = (u16*)CHAR_BASE_BLOCK(TILEBASE1);
u16* bgMap1  = (u16*)SCREEN_BASE_BLOCK(MAPBASE1);

u16* bgSubTile0 = (u16*)CHAR_BASE_BLOCK_SUB(SUBTILEBASE0);
u16* bgSubMap0  = (u16*)SCREEN_BASE_BLOCK_SUB(SUBMAPBASE0);

u16* bgSubTile1 = (u16*)CHAR_BASE_BLOCK_SUB(SUBTILEBASE1);
u16* bgSubMap1  = (u16*)SCREEN_BASE_BLOCK_SUB(SUBMAPBASE1);

u8 sndbfr[BUFFERSIZE];
u8 wavbfr[NUMBEROFAUDIO][BUFFERSIZE];
u8 random[1024];

int randIndex;
ArrowData arrow;

AIPLOT mapPlot[PLAYERS * 32 * 24]; 
int frame;
int tick;
int arrowStart;
bool redrawMapVB = true;
bool redrawMap = true;
void DrawMap();
void LoadWav(char* filename);
void PlayWav(int num);
const void* pFile;
void RotTileH(int dir);
void RotTileV(int dir);
void getInput(TurkeyData &turkeyz);
void SoundIndicator(bool visible,int screen, TurkeyData turkey0, TurkeyData turkey1);
bool hearingRadius(TurkeyData turkey0,TurkeyData turkey1,int radius);
bool seeingRadius(TurkeyData turkey0,TurkeyData turkey1,int radius);
inline void copyTurkeyData(TurkeyData &turkeydest,TurkeyData &turkeysrc);
void checkProjectiles();
void sortDead();
bool checkGameOver();
void Setup();
int BGTILES = 0;
int digStart = 0;
int wavCntr = 0;
PlaySampleSoundCommand wavHold[NUMBEROFAUDIO];
bool mainOnTop = false;  
u32 MapWidth = 0;
u32 MapHeight = 0;
void Vblank()
{
  
  DrawMap();
  frame++;
  frame %= 60;
  tick++;
}
SpriteEntry spritesSub[128];
SpriteEntry sprites[128];
pSpriteRotation spriteRotationsSub = (pSpriteRotation)spritesSub;
pSpriteRotation spriteRotations = (pSpriteRotation)sprites;
void updateOAM(void)
{
  DC_FlushAll();
	dmaCopy(sprites, OAM, 128 * sizeof(SpriteEntry));;
  dmaCopy(spritesSub, OAM_SUB, 128 * sizeof(SpriteEntry));

  
}

//turn off all the sprites
void initSprites(void)
{
  int i = 0;
	for(i = 0; i < 128; i++)
	{
	   sprites[i].attribute[0] = ATTR0_DISABLED;
	   sprites[i].attribute[1] = 0;
	   sprites[i].attribute[2] = 0;
	   sprites[i].attribute[3] = 0;
     spritesSub[i].attribute[0] = ATTR0_DISABLED;
	   spritesSub[i].attribute[1] = 0;
	   spritesSub[i].attribute[2] = 0;
	   spritesSub[i].attribute[3] = 0;  
  }
}


//---------------------------------------------------------------------------------
int main(void) {
//---------------------------------------------------------------------------------

  REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_SEND_CLEAR; // enable & prepare fifo asap
  POWER_CR = POWER_ALL_2D;	
	touchPosition touchXY;
	irqInit();
	irqSet(IRQ_VBLANK, Vblank);
  lcdMainOnBottom();
  defaultExceptionHandler();

  //fatInitDefault();
  WAIT_CR &= ~0x80;
  data_gbfs = find_first_gbfs_file((void*)0x08000000);

	
  LoadWav("turkey.wav");
  LoadWav("indiancall.wav");
  
  Setup();
  while(1)
  {
    
    for(int i = 0; i < TURKEYNUM; i++)
    {
      getInput(turkey[i]);
      
      if(turkey[i].sound)
        turkey[i].soundCounter--;
      if(turkey[i].soundCounter == 0)
        turkey[i].sound = false;
    
    }

    if(checkGameOver())
    {
      delete ai;
      Setup();
    }
    else
    {
      checkProjectiles();
      sortDead();
    
    }
    if(redrawMap)
      redrawMapVB = true;
    
    swiWaitForVBlank();
  }
  return 0;
}

void DrawMap()
{
  TurkeyData turkeyz;
  int heart;
  int spotX;
  int spotY;
  int x = 0, y = 0, map = 0;
  int sprite = 0;
  int spriteSub = 0;
  turkeyz.mapX = 0;
  turkeyz.mapY = 0;
  turkeyz.X = 0;
  turkeyz.Y = 0;
  turkeyz.posX = 0;
  turkeyz.posY = 0;
  trurkeyz.deg = DEGDOWN;  
  for(int i = 0; i < 128;i++)
  {
     sprites[i].attribute[0] = ATTR0_DISABLED;
     spritesSub[i].attribute[0] = ATTR0_DISABLED;
  }
  for(int i = 0; i < 8; i++)
  {
    //sets up the 8 rotations for sprites
    spriteRotations[i].hdx= (COS[i * 64]>>4);
    spriteRotations[i].hdy= (SIN[i * 64]>>4);
    spriteRotations[i].vdx=-(SIN[i * 64]>>4);
    spriteRotations[i].vdy= (COS[i * 64]>>4);

    spriteRotationsSub[i].hdx= (COS[i * 64]>>4);
    spriteRotationsSub[i].hdy= (SIN[i * 64]>>4);
    spriteRotationsSub[i].vdx=-(SIN[i * 64]>>4);
    spriteRotationsSub[i].vdy= (COS[i * 64]>>4);
  }
  //this is for flip
  spriteRotations[FLIP].hdx= -(1 << 8);
  spriteRotations[FLIP].hdy=  (0 << 8);
  spriteRotations[FLIP].vdx=  (0 << 8);
  spriteRotations[FLIP].vdy=  (1 << 8);

  spriteRotationsSub[FLIP].hdx= -1 << 8;
  spriteRotationsSub[FLIP].hdy=  0 << 8;
  spriteRotationsSub[FLIP].vdx=  0 << 8;
  spriteRotationsSub[FLIP].vdy=  1 << 8;

  if(redrawMapVB == true)
  {
    
    for(int i = 0; i < 825;i++)
    {
      map = x + (y * 64);
      turkeyz.mapX = turkey[0].mapX + x;
      turkeyz.mapY = turkey[0].mapY + y;
      turkeyz.X = turkey[0].X;
      turkeyz.Y = turkey[0].Y;
      turkeyz.posX = (turkeyz.mapX) * 8 + (turkeyz.X >> 12);
      turkeyz.posY = (turkeyz.mapY) * 8 + (turkeyz.Y >> 12);
    
      if(
         ( 
          (
            (turkey[0].type == NATIVE) && 
              (seeingRadius(turkey[0],turkeyz,200))
          ) ||
          (turkey[0].type == TURKEY)
         )
        )
      {
        bgMap0[map] = forest[(turkey[0].mapX + x) + (turkey[0].mapY + y) * MapWidth] & 31;
        bgMap1[map] = 32 + (forest[((turkey[0].mapX + x)) + ((turkey[0].mapY + y)) * MapWidth] >> 5) * 4  + ((((turkey[0].mapX + x)&1) | (((turkey[0].mapY + y))&1)<<1));
      }
      else
      {
      
        bgMap0[map] = 32;
        bgMap1[map] = 32;
      
      }
      
      turkeyz.mapX = turkey[1].mapX + x;
      turkeyz.mapY = turkey[1].mapY + y;
      turkeyz.X = turkey[1].X;
      turkeyz.X = turkey[1].Y;
      turkeyz.posX = (turkeyz.mapX) * 8 + (turkeyz.X >> 12);
      turkeyz.posY = (turkeyz.mapY) * 8 + (turkeyz.Y >> 12);
      if(
         ( 
          (
            (turkey[1].type == NATIVE) && 
              (seeingRadius(turkey[1],turkeyz,200))
          ) ||
          (turkey[1].type == TURKEY)
         )
        )
      {
        bgSubMap0[map] = forest[(turkey[1].mapX + x) + (turkey[1].mapY + y) * MapWidth] & 31;
        bgSubMap1[map] = 32 + (forest[((turkey[1].mapX + x)) + ((turkey[1].mapY + y)) * MapWidth] >> 5) * 4  + ((((turkey[1].mapX + x)&1) | (((turkey[1].mapY + y))&1)<<1));
      }
      else
      {
      
        bgSubMap0[map] = 32;
        bgSubMap1[map] = 32;
      
      }
      x++;
      if (x > 32)
      {
        y++;
        x = 0;
      }
    }
    redrawMap = false;
  }
    
  //Draws life
  if(frame < 30)
    heart = HEARTBIG;
  else
    heart = HEARTSMALL;

  if(turkey[0].type == NATIVE)
  {
    sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  0;
    sprites[sprite].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_16 | 0; // size 64x64, x 10
    sprites[sprite].attribute[2] = 24 | ATTR2_PRIORITY(0);
    sprite++;
    
    
    sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  12;
    sprites[sprite].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_8 | 20; // size 64x64, x 10
    sprites[sprite].attribute[2] = digStart + 20  | ATTR2_PRIORITY(0);
    sprite++;

    sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  12;
    sprites[sprite].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_8 | 28; // size 64x64, x 10
    sprites[sprite].attribute[2] = digStart + (((TURKEYNUM-2)) / 10)*2  | ATTR2_PRIORITY(0);
    sprite++;

    sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  12;
    sprites[sprite].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_8 | 36; // size 64x64, x 10
    sprites[sprite].attribute[2] = digStart + (((TURKEYNUM-2)) % 10)*2  | ATTR2_PRIORITY(0);
    sprite++;
    //////////////////////
    
    spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  0;
    spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_16 | 0; // size 64x64, x 10
    spritesSub[spriteSub].attribute[2] = 24 | ATTR2_PRIORITY(0);
    spriteSub++;
    
    
    spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  12;
    spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_8 | 20; // size 64x64, x 10
    spritesSub[spriteSub].attribute[2] = digStart + 20  | ATTR2_PRIORITY(0);
    spriteSub++;

    spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  12;
    spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_8 | 28; // size 64x64, x 10
    spritesSub[spriteSub].attribute[2] = digStart + (((TURKEYNUM-2)) / 10)*2  | ATTR2_PRIORITY(0);
    spriteSub++;

    spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  12;
    spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_8 | 36; // size 64x64, x 10
    spritesSub[spriteSub].attribute[2] = digStart + (((TURKEYNUM-2)) % 10)*2  | ATTR2_PRIORITY(0);
    spriteSub++;


  }


  for(int i = 0; i < turkey[0].container; i++)
  {
    if(turkey[0].life < (i + 1))
    {
      heart = HEARTEMPTY;
    }
    sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE | 26 * i + 10;
    sprites[sprite].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_16 | 225; // size 64x64, x 10
    sprites[sprite].attribute[2] = heart | ATTR2_PRIORITY(0);
    sprite++;
    

  }
  if(frame < 30)
    heart = HEARTBIG;
  else
    heart = HEARTSMALL;

  for(int i = 0; i < turkey[1].container; i++)
  {
    if(turkey[1].life < (i + 1))
    {
      heart = HEARTEMPTY;
    }
    spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE | 26 * i + 10;
    spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(0) | ATTR1_SIZE_16 | 225; // size 64x64, x 10
    spritesSub[spriteSub].attribute[2] = heart | ATTR2_PRIORITY(0);
    spriteSub++;
  }    
  //Draws the arrow for sound
  if(arrow.visible == ON)
  {   
    if((turkey[1].sound) && ((arrow.screen == MAIN) || (arrow.screen == BOTH)))
    {
      sprites[sprite].attribute[0] = ATTR0_COLOR_16 | ATTR0_ROTSCALE_DOUBLE | arrow.y;
      sprites[sprite].attribute[1] = ATTR1_ROTDATA(31) |ATTR1_SIZE_8 | arrow.x; // size 64x64, x 10
      sprites[sprite].attribute[2] = arrow.spr | ATTR2_PALETTE(15) | ATTR2_PRIORITY(0);
      spriteRotations[31].hdx =  (COS[arrow.deg]>>4);
      spriteRotations[31].hdy =  (SIN[arrow.deg]>>4);
      spriteRotations[31].vdx = -(SIN[arrow.deg]>>4);
      spriteRotations[31].vdy =  (COS[arrow.deg]>>4);
      sprite++;
    }
    if((turkey[0].sound) && ((arrow.screen == SUB) || (arrow.screen == BOTH)))
    {
      spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_16 | ATTR0_ROTSCALE_DOUBLE | arrow.y;
      spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(31) | ATTR1_SIZE_8 | arrow.x; // size 64x64, x 10
      spritesSub[spriteSub].attribute[2] = arrow.spr |ATTR2_PALETTE(15) | ATTR2_PRIORITY(0);
      spriteRotationsSub[31].hdx =  (COS[arrow.deg]>>4);
      spriteRotationsSub[31].hdy =  (SIN[arrow.deg]>>4);
      spriteRotationsSub[31].vdx = -(SIN[arrow.deg]>>4);
      spriteRotationsSub[31].vdy =  (COS[arrow.deg]>>4);
      spriteSub++;
    }
  }  
  //Draw projectiles
  for(int i = 0; i < TURKEYNUM; i++)
  {
    if(turkey[i].projectile == false)
      continue;
    spotX = turkey[i].projectilePosX - turkey[0].posX;
    spotY = turkey[i].projectilePosY - turkey[0].posY;
    turkeyz.posX = turkey[i].projectilePosX;
    turkeyz.posY = turkey[i].projectilePosY;
    
    if(
        (ABS(spotX)<128) &&
        (ABS(spotY)<96) && ( 
          (
            (turkey[0].type == NATIVE) && 
              (seeingRadius(turkey[0],turkeyz,200))
              
          ) ||
          (turkey[0].type == TURKEY)
        )
      )
    {
      
      sprites[sprite].attribute[0] = ATTR0_COLOR_16 | ATTR0_ROTSCALE_DOUBLE | spotY + 88;
      sprites[sprite].attribute[1] = ATTR1_ROTDATA(turkey[i].projectileDeg) | ATTR1_SIZE_8 | spotX + 120; // size 64x64, x 10
      sprites[sprite].attribute[2] = turkey[i].projectileSpr | ATTR2_PALETTE(14) | ATTR2_PRIORITY(2);
      sprite++;
    }
      
    spotX = turkey[i].projectilePosX - turkey[1].posX;
    spotY = turkey[i].projectilePosY - turkey[1].posY;
    turkeyz.posX = turkey[i].projectilePosX;
    turkeyz.posY = turkey[i].projectilePosY;
    
    if(
        (ABS(spotX)<128) &&
        (ABS(spotY)<96) &&
        ( 
          (
            (turkey[1].type == NATIVE) && 
              (seeingRadius(turkey[1],turkeyz,200))
          ) ||
          (turkey[1].type == TURKEY)
        )
      )
    {
      spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_16 | ATTR0_ROTSCALE_DOUBLE | spotY + 88;
      spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(turkey[i].projectileDeg) | ATTR1_SIZE_8 | spotX + 120; // size 64x64, x 10
      spritesSub[spriteSub].attribute[2] = turkey[i].projectileSpr | ATTR2_PALETTE(14) | ATTR2_PRIORITY(2);
      spriteSub++;
    }
  }
  
  //Draws turkeys Main
  if(turkey[0].life > 0)
  {
    sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE | 80;
    sprites[sprite].attribute[1] = ATTR1_ROTDATA(turkey[0].rot) | ATTR1_SIZE_16 | 112; // size 64x64, x 10
    sprites[sprite].attribute[2] = turkey[0].spr | ATTR2_PRIORITY(2);
    sprite++;
  }
  for(int i = 1; i < TURKEYNUM; i++)
  {
    spotX = turkey[i].posX - turkey[0].posX;
    spotY = turkey[i].posY - turkey[0].posY;
    if(
        (turkey[i].life > 0) &&
        (ABS(spotX)<120) &&
        (ABS(spotY)<88)  &&
        ( 
          (
            (turkey[0].type == NATIVE) && 
              (seeingRadius(turkey[0],turkey[i],200)
                ||
              hearingRadius(turkey[0],turkey[i],200))
          ) ||
          (turkey[0].type == TURKEY)
        )
        
      )
    {
      sprites[sprite].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE |  80 + spotY;
      sprites[sprite].attribute[1] = ATTR1_ROTDATA(turkey[i].rot) | ATTR1_SIZE_16 | 112 + spotX; // size 64x64, x 10
      sprites[sprite].attribute[2] = turkey[i].spr | ATTR2_PRIORITY(2);
      sprite++;
    }
  }
    
  //Draws turkeys Sub
  if(turkey[1].life > 0)
  {
    spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE | 80;
    spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(turkey[1].rot) | ATTR1_SIZE_16 | 112; // size 64x64, x 10
    spritesSub[spriteSub].attribute[2] = turkey[1].spr | ATTR2_PRIORITY(2);
    spriteSub++;
  }
  for(int i = 0; i < TURKEYNUM; i++)
  {
    if(i == 1) continue;
    spotX = turkey[i].posX - turkey[1].posX;
    spotY = turkey[i].posY - turkey[1].posY;
    
    if(
        (ABS(spotX)<120) &&
        (ABS(spotY)<88) &&
        (turkey[i].life > 0) &&
        (
          ( 
            (turkey[1].type == NATIVE) && 
              (seeingRadius(turkey[1],turkey[i],200)
                ||
              hearingRadius(turkey[1],turkey[i],200))
          ) ||
          (turkey[1].type == TURKEY)
        )
      )
    {
      spritesSub[spriteSub].attribute[0] = ATTR0_COLOR_256 | ATTR0_ROTSCALE_DOUBLE | 80 + spotY  ;
      spritesSub[spriteSub].attribute[1] = ATTR1_ROTDATA(turkey[i].rot) |ATTR1_SIZE_16 | 112 + spotX; // size 64x64, x 10
      spritesSub[spriteSub].attribute[2] = turkey[i].spr | ATTR2_PRIORITY(2);
      spriteSub++;
    }
  }
  
  BG3_CX = turkey[0].X >> 4; 
  BG3_CY = turkey[0].Y >> 4; 
  SUB_BG3_CX = turkey[1].X >> 4; 
  SUB_BG3_CY = turkey[1].Y >> 4;
  BG2_CX = turkey[0].X >> 4; 
  BG2_CY = turkey[0].Y >> 4; 
  SUB_BG2_CX = turkey[1].X >> 4; 
  SUB_BG2_CY = turkey[1].Y >> 4; 
  updateOAM();  
}

void RotTileV(int dir)
{
  int temp,x,y, tile ;
  for(tile = 0; tile < BGTILES; tile++)
  {
    for(x = 0; x < 8; x++)
    {
      if(dir == 1)
      {
        temp = bgTile0[x + tile * 64];
        for(y = 0; y < 8; y++)
        {
          bgTile0[x + (y * 8) + tile * 64] = 
            bgTile0[x + (y * 8) + tile * 64];
        }
        bgTile0[x + 56 + tile * 64] = temp;
      }
      if(dir == -1)
      {
        temp = bgTile0[x + 56 + tile * 64];
        for(y = 7; y > -1; y--)
        {
          bgTile0[x + (y * 8) + tile * 64] = 
            bgTile0[x + (y * 8) + tile * 64];
        }
        bgTile0[x + tile * 64] = temp;
      }
    }
  }
}

void RotTileH(int dir)
{
  int temp,x,y,tile;
  for(tile = 0; tile < BGTILES; tile++)
  {
    for(y = 0; y < 8; y++)
    {
      if(dir == 1)
      {
        temp = bgTile0[0 + (y * 8) + tile * 64];
        for(x = 0; x < 8; x++)
        {
          bgTile0[x + (y * 8) + tile * 64] = 
            bgTile0[x + (y * 8) + tile * 64];
        }
        bgTile0[7 + (y * 8) + tile * 64] = temp;
      }
      if(dir == -1)
      {
        temp = bgTile0[7 + (y * 8) + tile * 64];
        for(x = 7; x > -1; x--)
        {
          bgTile0[x + (y * 8) + tile * 64] = 
            bgTile0[x + (y * 8) + tile * 64];
        }
        bgTile0[0 + (y * 8) + tile * 64] = temp;
      }
    }
  }
}

inline void getInput(TurkeyData &turkeyz)
{
  TurkeyData oldTurkey;
  int x = 0,y = 0;
  int spotX, spotY;
  
  int temp;
  int spot;
  u16 keyInput = 0;
  u16 keyDown = 0;
  ai->friendCnt = 0;
  ai->enemyCnt = 0;
  ai->coverCnt = 0;
  if (turkeyz.input == PAD)
  {
    scanKeys();
    keyInput = keysHeld();
    keyDown = keysDown();
    if(keyDown & KEY_R)
    {
      mainOnTop = !mainOnTop;
      lcdSwap();
      if(mainOnTop)
      {
         turkey[1].input = PAD;
         turkey[0].input = AI;
      }
      else
      {
         turkey[0].input = PAD;
         turkey[1].input = AI;
      }
      
 
    }
  }
  
  if(keyDown & KEY_LID)
  {
    
    //keyDown = 0;
    REG_IPC_FIFO_TX = LED_SLOW_FLASH;
    swiWaitForVBlank();
    REG_IPC_FIFO_TX = LIGHT_OFF;
    swiWaitForVBlank();
    while((keyDown & KEY_LID))
    {
      scanKeys();
      keyDown = keysHeld();
      
    }
    REG_IPC_FIFO_TX = LIGHT_ON;
    swiWaitForVBlank();
    REG_IPC_FIFO_TX = LED_ON;
    swiWaitForVBlank();
  }
 
  if (turkeyz.input == AI)
  {
    
    
    for(u32 i = 0; i < ai->MapWidth*ai->MapHeight;i++)
    {
      spot = (x/2) + (y/2) * ai->MapWidth;
      temp = (forest[(turkeyz.mapX + x - 1) + (turkeyz.mapY + y - 1) * MapWidth] >> 5);
      if( temp > 2)
        ai->MapList[spot].status = AI_OBSTACLE;
      else if(temp > 0)
      {
        ai->MapList[spot].status = AI_COVER;
        ai->coverArray[ai->coverCnt].Col = x/2 ;
        ai->coverArray[ai->coverCnt].Row = y/2 ;
        ai->coverCnt++;
      }
      else
        ai->MapList[spot].status = AI_NONE;
      
      
      x+= 2;
      if (x > 33)
      {
        y+=2;
        x = 0;
      }
    }
    
    
    
    for(int i = 0; i < TURKEYNUM;i++)
    {
         
      spotX = turkey[i].posX - turkeyz.posX;
      spotY = turkey[i].posY - turkeyz.posY;
      
      if(
          (ABS(spotX)<128) &&
          (ABS(spotY)<96) &&
          (ABS(spotX) != 0) &&
          (ABS(spotX) != 0) &&
          (
            (
              (turkeyz.type == NATIVE) && 
                (seeingRadius(turkeyz,turkey[i],200) ||
                  hearingRadius(turkeyz,turkey[i],200))
            ) ||
            (turkeyz.type == TURKEY)
          )
         )
      {
        
        if(turkeyz.type != turkey[i].type)
        {
          
          ai->MapList[((128+spotX)>>4) + ((96+spotY)>>4) * ai->MapWidth].status = AI_ENEMY ;
          
          ai->enemyArray[ai->enemyCnt].Col = ((spotX+128)>>4) ;
          ai->enemyArray[ai->enemyCnt].Row = ((spotY+96)>>4) ;
          
          ai->enemyCnt++;
          
        }
        else
        {
          
          if((turkeyz.type == NATIVE)||((turkeyz.type == TURKEY) && (turkey[i].mate == true)))
          {
            ai->MapList[((128+spotX)>>4) + ((96+spotY)>>4) * ai->MapWidth].status = AI_FRIEND ;
            ai->friendArray[ai->friendCnt].Col = ((spotX+128)>>4) ;
            ai->friendArray[ai->friendCnt].Row = ((spotY+96)>>4) ;
            ai->friendCnt++;
            
          }
          
          
        }
        
       }     
    }
     
    
    if
      (
      (turkeyz.type == TURKEY)&&
      (turkeyz.mate == true)&&
      (arrow.visible == ON)
      )
    {
      spotX = (arrow.x);
      spotY = (arrow.y);
      ai->MapList[((spotX)>>4) + ((spotY)>>4) * ai->MapWidth].status = AI_FRIEND ;
      ai->friendArray[ai->friendCnt].Col = ((spotX)>>4) ;
      ai->friendArray[ai->friendCnt].Row = ((spotY)>>4) ;
      ai->friendCnt++;
      
    }
 
  // if (turkeyz.input == AI)
   keyDown = keyInput = ai->getInput(turkeyz);
 /*
   */ 
  }

  
 
  
   for(int i = 0; i < turkeyz.speed;i++)
  {
    //if(redrawMap)
    //  redrawMapVB = true;
    
    
    copyTurkeyData(oldTurkey,turkeyz);
      
    if(keyInput & KEY_LEFT)
    {  
      if(turkeyz.mapX + (turkeyz.X>>12) > 0)
        turkeyz.X -= 1 << 12;
      if((turkeyz.X>>12) < 0)
      {
        turkeyz.X = 7 << 12;
        turkeyz.mapX--;
        if(turkeyz.mapX < 0)
          turkeyz.mapX = 0;
        else
          redrawMap = true;
      }
      turkeyz.rot = FLIP;
      turkeyz.deg = DEGLEFT;
      
      if(!(keyInput & KEY_DOWN) && !(keyInput & KEY_UP))
      {
        if(turkeyz.spr == 16 + (turkeyz.type * 48))
          turkeyz.spr = 24 + (turkeyz.type * 48);
        else
          turkeyz.spr = 16 + (turkeyz.type * 48);
      }
      
    }
    if(keyInput & KEY_RIGHT)
    {
      if((turkeyz.mapX * 8 + (turkeyz.X>>12)) < 991 * 8 )
        turkeyz.X += 1 << 12;
      
      if((turkeyz.X>>12) > 7)
      {
        turkeyz.X = 0;
        turkeyz.mapX++;
        if(turkeyz.mapX >= MapWidth - 33)
          turkeyz.mapX = MapWidth - 33;
        else
          redrawMap = true;
      }
      turkeyz.rot = DEGDOWN;
      turkeyz.deg = DEGRIGHT;
      
      if(!(keyInput & KEY_DOWN) && !(keyInput & KEY_UP))
      {
        if(turkeyz.spr == 16 + (turkeyz.type * 48))
          turkeyz.spr = 24 + (turkeyz.type * 48);
        else
          turkeyz.spr = 16 + (turkeyz.type * 48);
      }
      
    }
    if(keyInput & KEY_UP)
    {
      if((turkeyz.mapY*8 + (turkeyz.Y>>12)) > 0)
        turkeyz.Y-= 1 << 12;
    
      if((turkeyz.Y>>12) < 0)
      {
        turkeyz.Y = 7 << 12;
        turkeyz.mapY--;
        if(turkeyz.mapY < 0)
          turkeyz.mapY = 0;    
        else
          redrawMap = true;
      }
      turkeyz.rot = DEGDOWN;
      turkeyz.deg = DEGUP;
      
      if(!(keyInput & KEY_LEFT) && !(keyInput & KEY_RIGHT))
      {
        if(turkeyz.spr == 32 + (turkeyz.type * 48))
          turkeyz.spr = 40 + (turkeyz.type * 48);
        else
          turkeyz.spr = 32 + (turkeyz.type * 48);
      }
    
    }
    if(keyInput & KEY_DOWN)
    {
      if((turkeyz.mapY*8 + (turkeyz.Y>>12)) < ((MapWidth - 25) * 8))
        turkeyz.Y += 1 << 12;
    
      if((turkeyz.Y>>12) > 7)
      {
        turkeyz.Y = 0;
        turkeyz.mapY++;
        if(turkeyz.mapY > 999)
          turkeyz.mapY = 999;
        else
          redrawMap = true;
      }
      turkeyz.rot = DEGDOWN;
      turkeyz.deg = DEGDOWN; 
      if(!(keyInput & KEY_LEFT) && !(keyInput & KEY_RIGHT))
      {
        if(turkeyz.spr == 0 + (turkeyz.type * 48))
          turkeyz.spr = 8 + (turkeyz.type * 48);
        else
          turkeyz.spr = 0 + (turkeyz.type * 48);
      }
    }
    
    if((keyInput & KEY_UP) && (keyInput & KEY_RIGHT))
    {
      turkeyz.rot= DEGDOWNLEFT;
      turkeyz.deg = DEGUPRIGHT;
      if(turkeyz.spr == 32 + (turkeyz.type * 48))
        turkeyz.spr = 40 + (turkeyz.type * 48);
      else
        turkeyz.spr = 32 + (turkeyz.type * 48);
      turkeyz.Y += 1 << 11;
      turkeyz.X -= 1 << 11;
    }
    if((keyInput & KEY_UP) && (keyInput & KEY_LEFT))
    {
      turkeyz.rot = DEGDOWNRIGHT;
      turkeyz.deg = DEGUPLEFT;
      if(turkeyz.spr == 32 + (turkeyz.type * 48))
        turkeyz.spr = 40 + (turkeyz.type * 48);
      else
        turkeyz.spr = 32 + (turkeyz.type * 48);
      turkeyz.Y += 1 << 11;
      turkeyz.X += 1 << 11;
    }
    if((keyInput & KEY_DOWN) && (keyInput & KEY_RIGHT))
    {
      turkeyz.deg = DEGDOWNRIGHT;
      turkeyz.rot = DEGDOWNRIGHT;
      if(turkeyz.spr == 0 + (turkeyz.type * 48))
        turkeyz.spr = 8 + (turkeyz.type * 48);
      else
        turkeyz.spr = 0 + (turkeyz.type * 48);
      turkeyz.Y -= 1 << 11;
      turkeyz.X -= 1 << 11;
    }
    if((keyInput & KEY_DOWN) && (keyInput & KEY_LEFT))
    {
      turkeyz.deg = DEGDOWNLEFT;
      turkeyz.rot = DEGDOWNLEFT;
      if(turkeyz.spr == 0 + (turkeyz.type * 48))
        turkeyz.spr = 8 + (turkeyz.type * 48);
      else
        turkeyz.spr = 0 + (turkeyz.type * 48);
      turkeyz.Y -= 1 << 11;
      turkeyz.X += 1 << 11;

    }

    
    turkeyz.posX = (turkeyz.mapX + 15) * 8 + (turkeyz.X >> 12);
    turkeyz.posY = (turkeyz.mapY + 11) * 8 + (turkeyz.Y >> 12);
    if(
       ((forest[
               ((((turkeyz.posX-7) >> 3))+1) + 
               ((((turkeyz.posY-7) >> 3))+1) * MapWidth
          ]>>5) > 2) ||
       ((forest[
               ((((turkeyz.posX) >> 3))+2) + 
               ((((turkeyz.posY-7) >> 3))+1) * MapWidth
          ]>>5) > 2) ||
       ((forest[
               ((((turkeyz.posX-7) >> 3))+1) + 
               ((((turkeyz.posY) >> 3))+2) * MapWidth
          ]>>5) > 2) ||
       ((forest[
               ((((turkeyz.posX) >> 3))+2) + 
               ((((turkeyz.posY) >> 3))+2) * MapWidth
          ]>>5) > 2)
      )
    {
      copyTurkeyData(turkeyz,oldTurkey);
    }
      
  } 
  

  if(keyDown & KEY_A)
  {
    if(turkeyz.type == TURKEY)
    {
      PlayWav(0);
      if(mainOnTop)
        SoundIndicator(ON,MAIN,turkey[1],turkey[0]);    
      else
        SoundIndicator(ON,SUB,turkey[0],turkey[1]);    
      turkeyz.sound = true;
      turkeyz.soundCounter = 180;
      redrawMap = true;
    }
    else if (turkeyz.type == NATIVE)
    {
      if(turkeyz.projectile != true)
      {
        turkeyz.projectile = true;
        turkeyz.projectilePosX = turkeyz.posX;
        turkeyz.projectilePosY = turkeyz.posY;
        turkeyz.projectileSpr = arrowStart + 1;
        turkeyz.projectileCounter = 20;
        if((turkeyz.spr == 48) ||(turkeyz.spr == 56))
        {
          if(turkeyz.rot == DEGDOWNLEFT)
            turkeyz.projectileDeg = DEGDOWNLEFT;
          else if(turkeyz.rot == DEGDOWNRIGHT)
            turkeyz.projectileDeg = DEGDOWNRIGHT;
          else
            turkeyz.projectileDeg = DEGDOWN;
        
        }
        if((turkeyz.spr == 80) ||(turkeyz.spr == 88))
        {
          if(turkeyz.rot == DEGDOWNLEFT)
            turkeyz.projectileDeg = DEGUPRIGHT;
          else if(turkeyz.rot == DEGDOWNRIGHT)
            turkeyz.projectileDeg = DEGUPLEFT;
          else
            turkeyz.projectileDeg = DEGUP;
        
        }
        if((turkeyz.spr == 64) ||(turkeyz.spr == 72))
        {
          if(turkeyz.rot ==  FLIP)
            turkeyz.projectileDeg = DEGLEFT;
          else
            turkeyz.projectileDeg = DEGRIGHT;
          
        
        }
        PlayWav(1);
        
      }
    }
  }
  

}

void LoadWav(char* filename)
{
  WAVEHEADER wavehdr;
  
  u32 length = 0;
  u32 dataSize = 0;
  const void* pFile = fileIn(filename, length);
  memcpy(&wavehdr,pFile,sizeof(WAVEHEADER));
  dataSize = length - sizeof(WAVEHEADER);
  if (dataSize > BUFFERSIZE)
     dataSize = BUFFERSIZE;
  if(wavehdr.wBitsPerSample == 16)
  {
    wavHold[wavCntr].depth = SOUND_16BIT;
    for(unsigned int cnvr = 0;cnvr < dataSize; cnvr++)
      wavbfr[wavCntr][cnvr] = (((((u8*)pFile)[cnvr] & 0x7F) << 5) | ((((u8*)pFile)[cnvr]>>3)&0x1F)) ;
  }
  if(wavehdr.wBitsPerSample == 8)
  {
    wavHold[wavCntr].depth = SOUND_8BIT;
    for(unsigned int cnvr = 0;cnvr < dataSize; cnvr++)
      wavbfr[wavCntr][cnvr] = (((u8*)pFile)[cnvr] ^ BIT(7)) ;
  }
  
  wavHold[wavCntr].channel = wavCntr;
  wavHold[wavCntr].frequency = wavehdr.nAvgBytesPerSec;
  wavHold[wavCntr].data = &sndbfr;
  wavHold[wavCntr].length = dataSize;
  wavHold[wavCntr].volume = 127;
  wavCntr++;
}

void PlayWav(int num)
{
  PlaySampleSoundCommand* ps = playSound;
  memcpy(sndbfr,&wavbfr[num],wavHold[num].length);
  
  memcpy(ps,&wavHold[num],sizeof(PlaySampleSoundCommand));
  REG_IPC_FIFO_TX = PLAY_ONCE;
  
}

void SoundIndicator(bool visible,int screen, TurkeyData turkey0, TurkeyData turkey1)
{
  int deg = 256;
  int distX = turkey1.posX - turkey0.posX;
  int distY = turkey1.posY - turkey0.posY;
  int tempY = 96;
  int tempX = 128;
  
  if(ABS(distX) < 128)
  {
    tempX -= distX + 7;
  }
  else if (distX > 0)
  {
    tempX = 0;
  }
  else if(distX < 0)
  {
    tempX = 239;
  }
  
  if(ABS(distY) < 96)
  {
    tempY -= distY + 7;
  }
  else if (distY > 0)
  {
    tempY = 0;
  }  
  else if(distY < 0)
  {
    tempY = 175;
  }
  
  if((ABS(distX) < 128) && (ABS(distY) < 96))
  {
    //tempX -= distX;
    visible = false;
  }
  
  arrow.x = tempX;
  arrow.y = tempY;
  arrow.spr = arrowStart;
  arrow.screen = screen;
  arrow.deg = deg;
  arrow.visible = visible;
}
  


//Purpose:  Creates a sound radius   
//Input:    the 2 players to compare and the listening radius
//Output:   None
bool hearingRadius(TurkeyData turkey0,TurkeyData turkey1,int radius)
{

  int distX  = ((turkey0.posX) - (turkey1.posX)) * ((turkey0.posX) - (turkey1.posX));
  int distY  = ((turkey0.posY) - (turkey1.posY)) * ((turkey0.posY) - (turkey1.posY));
  if (((distX + distY)) < (radius * radius) && turkey1.sound)
    return true;
  
  return false;
}


//Purpose:  Creates sight   
//Input:    the 2 players to compare and the listening radius
//Output:   None
bool seeingRadius(TurkeyData turkey0,TurkeyData turkey1,int radius)
{
  
  int distX  = ((turkey0.posX) - (turkey1.posX)) * ((turkey0.posX) - (turkey1.posX));
  int distY  = ((turkey0.posY) - (turkey1.posY)) * ((turkey0.posY) - (turkey1.posY));
  int difX = ((turkey1.posX + (turkey1.X>>12)) - (turkey0.posX + (turkey0.X>>12)+7));
  int difY = ((turkey1.posY + (turkey1.Y>>12)) - (turkey0.posY + (turkey0.Y>>12)+7));
  //if it is greater then distance, return false
  if (((distX + distY)) > (radius * radius))
    return false;
  //check to see if they can be seen
  switch(turkey0.deg)
  {
    case DEGDOWN:
      if(
         (difY > 0) &&
         (ABS(difY)) >= (ABS(difX) ) 
        )
        return true;
    break;
    case DEGDOWNLEFT:
      if(
         (difY > 0) &&
         (difX < 0) 
        )
        return true;
    break;
    case DEGLEFT:
      if(
         (difX < 0) &&
         (ABS(difY)) <= (ABS(difX)) 
        )
        return true;
    break;
    case DEGUPLEFT:
      if(
         (difY < 0) &&
         (difX < 0) 
        )
        return true;
    break;
    case DEGUP:
      if(
         (difY < 0) &&
         (ABS(difX)) <= (ABS(difY)) 
        )
        return true;
    break;
    case DEGUPRIGHT:
      if(
         (difY < 0) &&
         (difX > 0) 
        )
        return true;
    break;
    case DEGRIGHT:
        if(
         (difX > 0) &&
         (ABS(difY)) <= (ABS(difX)) 
        )
        return true;
    break;
    case DEGDOWNRIGHT:
      if(
         (difY > 0) &&
         (difX > 0) 
        )
        return true;
    break;
    case FLIP:
    break;
  }
  
  
  return false;
}

inline void copyTurkeyData(TurkeyData &turkeydest,TurkeyData &turkeysrc)
{
  turkeydest.X = turkeysrc.X;
  turkeydest.Y = turkeysrc.Y;
  turkeydest.mapX = turkeysrc.mapX;
  turkeydest.mapY = turkeysrc.mapY;
  turkeydest.posX = turkeysrc.posX;
  turkeydest.posY = turkeysrc.posY;
  turkeydest.spr = turkeysrc.spr;
  turkeydest.rot = turkeysrc.rot;
  turkeydest.speed = turkeysrc.speed;
  turkeydest.input = turkeysrc.input;
  turkeydest.type = turkeysrc.type;
  turkeydest.projectile = turkeysrc.projectile;
  turkeydest.projectileDeg = turkeysrc.projectileDeg;
  turkeydest.projectilePosX = turkeysrc.projectilePosX;
  turkeydest.projectilePosY = turkeysrc.projectilePosY;
  turkeydest.projectileSpr = turkeysrc.projectileSpr;
  turkeydest.projectileCounter = turkeysrc.projectileCounter;
  turkeydest.life = turkeysrc.life;
  turkeydest.container = turkeysrc.container;
  
}

void checkProjectiles()
{
  
  int oldPosX = 0;
  int oldPosY = 0;
  int dx = 0;
  int dy = 0;
  int inc = 0;
  for(int i = 0; i < TURKEYNUM; i++)
  {
    oldPosX = turkey[i].projectilePosX;
    oldPosY = turkey[i].projectilePosY;
    if(!turkey[i].projectile)
      continue;
    switch(turkey[i].projectileDeg)
    {
      case DEGDOWN:
        dx = 0;
        dy = 1;
        inc = 16;
      break;
      case DEGDOWNLEFT:
        dx = -1;
        dy = 1;
        inc = 12;
      break;
      case DEGDOWNRIGHT:
        dx = 1;
        dy = 1;
        inc = 12;
      break;
      case DEGUP:
        dx = 0;
        dy = -1;
        inc = 16;
      break;
      case DEGUPLEFT:
        dx = -1;
        dy = -1;
        inc = 12;
      break;
      case DEGUPRIGHT:
        dx = 1;
        dy = -1;
        inc = 12;
      break;
      case DEGLEFT:
        dx = -1;
        dy = 0;
        inc = 16;
      break;
      case DEGRIGHT:
        dx = 1;
        dy = 0;
        inc = 16;
      break;
      case FLIP:
      break;
    }
    
    for(int k = 0; k < inc;k++)
    {
      if(
       ((forest[
               (((turkey[i].projectilePosX >> 3))+1) + 
               (((turkey[i].projectilePosY >> 3))+1) * MapWidth
          ]>>5) > 2))
      {
        turkey[i].projectile = false;
        turkey[i].projectilePosX = -1;
        turkey[i].projectilePosY = -1;
        break;
      }
      for(int j  = 0; j < TURKEYNUM; j++)
      {
    
        if(
           ((turkey[i].projectilePosX >= turkey[j].posX - 7) &&
           (turkey[i].projectilePosX <= turkey[j].posX + 7))
           &&
           ((turkey[i].projectilePosY >= turkey[j].posY - 7) &&
           (turkey[i].projectilePosY <= turkey[j].posY + 7))
          )
        {
          if(i != j)
          {
            turkey[j].life--;
            turkey[i].projectile = false;
            turkey[i].projectilePosX = -1;
            turkey[i].projectilePosY = -1;
            if(turkey[j].type == TURKEY)
            PlayWav(0);
            if(hearingRadius(turkey[i],turkey[j],400))
            {
              SoundIndicator(ON,BOTH,turkey[i],turkey[j]);    
      
              
              turkey[j].sound = true;
              turkey[j].soundCounter = 180;
      
            }
        
          }
        }
      }
      turkey[i].projectilePosX += dx;
      if(turkey[i].projectilePosX >= (MapWidth*8)-8)
        turkey[i].projectilePosX = (MapWidth*8)-8;
        
      turkey[i].projectilePosY += dy;
      if(turkey[i].projectilePosY >= (MapHeight*8)-8)
        turkey[i].projectilePosY =  (MapWidth*8)-8;

      if(turkey[i].projectilePosX <= 0)
        turkey[i].projectilePosX = 0;
        
      if(turkey[i].projectilePosY <= 0)
        turkey[i].projectilePosY =  0;
    }
    
    turkey[i].projectileCounter--;
    if(turkey[i].projectileCounter == 0)
      turkey[i].projectile = false;
    
    
    
  }
}

void sortDead()
{
  TurkeyData temp;
  for(int i = 2; i < TURKEYNUM;i++)
  {
    if(turkey[i].life <=0)
    {
      copyTurkeyData(temp,turkey[i]);
      copyTurkeyData(turkey[i],turkey[TURKEYNUM - 1]);
      copyTurkeyData(turkey[TURKEYNUM - 1],temp);
      TURKEYNUM--; 
   }
  }
}

bool checkGameOver()
{
  u32 length;
  int x = 0,y = 0, map = 0;
  
  
  if((turkey[0].life <= 0) ||(turkey[1].life <= 0))
  {
    if(mainOnTop)
    {
      lcdSwap();
      mainOnTop = false;
    }
    redrawMap = false;
    redrawMapVB = false;
    videoSetMode   (MODE_5_2D | DISPLAY_BG3_ACTIVE);	//not using the main screen
    videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);	//sub bg 0 will be used to print text
    BG3_CX = 0;
    SUB_BG3_CX = 0;
    BG3_CY = 0;
    SUB_BG3_CY = 0;
    
	  BG3_CR = BG_RS_32x32 | BG_MAP_BASE(MAPBASE0)|BG_TILE_BASE(TILEBASE0)|BG_PRIORITY(3);
  
	  SUB_BG3_CR =  BG_RS_32x32  | BG_MAP_BASE(SUBMAPBASE0)|BG_TILE_BASE(SUBTILEBASE0)|BG_PRIORITY(3);

    //make up a bad game over screen
    memset(BG_PALETTE,0,512);
    memset(BG_PALETTE_SUB,0,512);
  
    memset(bgMap0,0,2048);
    memset(bgSubMap0,0,2048);
  
    memset(bgTile0,0,65536);
    memset(bgSubTile0,0,65536); 
  
    pFile = fileIn("gameover.pal",length);
    dmaCopy(pFile,BG_PALETTE_SUB,length);
    pFile = fileIn("youredead.pal",length);
    dmaCopy(pFile,BG_PALETTE,length);
  
    pFile = fileIn("gameover.map",length);
    dmaCopy(pFile,bgSubMap0,length);
    pFile = fileIn("youredead.map",length);
    dmaCopy(pFile,bgMap0,length);
  
    pFile = fileIn("gameover.tle",length);
    dmaCopy(pFile,bgSubTile0,length);
    pFile = fileIn("youredead.tle",length);
    dmaCopy(pFile,bgTile0,length);
    for(int i = 0; i < 300; i++)
      swiWaitForVBlank();
    return true;
  }
  
  if (turkey[0].type == TURKEY)
  {
    
    if((turkey[0].mapX >= turkey[1].mapX) && (turkey[0].mapX <= turkey[1].mapX + 1) && 
       (turkey[0].mapY >= turkey[1].mapY) && (turkey[0].mapY <= turkey[1].mapY + 1) ||
       (turkey[0].mapX + 1 >= turkey[1].mapX) && (turkey[0].mapX + 1 <= turkey[1].mapX + 1) && 
       (turkey[0].mapY + 1 >= turkey[1].mapY) && (turkey[0].mapY + 1 <= turkey[1].mapY + 1) ||
       (turkey[0].mapX >= turkey[1].mapX) && (turkey[0].mapX <= turkey[1].mapX + 1) && 
       (turkey[0].mapY + 1 >= turkey[1].mapY) && (turkey[0].mapY + 1 <= turkey[1].mapY + 1)||
       (turkey[0].mapX + 1 >= turkey[1].mapX) && (turkey[0].mapX + 1 <= turkey[1].mapX + 1) && 
       (turkey[0].mapY >= turkey[1].mapY) && (turkey[0].mapY <= turkey[1].mapY + 1)
       ) 
    {
      if(mainOnTop)
      {
        lcdSwap();
        mainOnTop = false;
      }
      redrawMap = false;
      redrawMapVB = false;
      videoSetMode   (MODE_5_2D | DISPLAY_BG3_ACTIVE);	//not using the main screen
      videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);	//sub bg 0 will be used to print text
  
      BG3_CR = BG_RS_32x32 | BG_MAP_BASE(MAPBASE0)|BG_TILE_BASE(TILEBASE0)|BG_PRIORITY(3);
  
      SUB_BG3_CR =  BG_RS_32x32  | BG_MAP_BASE(SUBMAPBASE0)|BG_TILE_BASE(SUBTILEBASE0)|BG_PRIORITY(3);
      BG3_CX = 0;
      SUB_BG3_CX = 0;
      BG3_CY = 0;
      SUB_BG3_CY = 0;
    
      //make up a bad game over screen
      memset(BG_PALETTE,0,512);
      memset(BG_PALETTE_SUB,0,512);
  
      memset(bgMap0,0,2048);
      memset(bgSubMap0,0,2048);
  
      memset(bgTile0,0,65536);
      memset(bgSubTile0,0,65536); 
  
      pFile = fileIn("congratsT.pal",length);
      dmaCopy(pFile,BG_PALETTE_SUB,length);
      pFile = fileIn("happy.pal",length);
      dmaCopy(pFile,BG_PALETTE,length);
  
      pFile = fileIn("congratsT.map",length);
      dmaCopy(pFile,bgSubMap0,length);
      pFile = fileIn("happy.map",length);
      dmaCopy(pFile,bgMap0,length);
  
      pFile = fileIn("congratsT.tle",length);
      dmaCopy(pFile,bgSubTile0,length);
      pFile = fileIn("happy.tle",length);
      dmaCopy(pFile,bgTile0,length);
      for(int i = 0; i < 300; i++)
        swiWaitForVBlank();
      return true;
    }
  }
  if (turkey[0].type == NATIVE)
  {
  
    if (TURKEYNUM <= 2)
    {
      if(mainOnTop)
      {
        lcdSwap();
        mainOnTop = false;
      }
       redrawMap = false;
      redrawMapVB = false;
      videoSetMode   (MODE_5_2D | DISPLAY_BG3_ACTIVE);	//not using the main screen
      videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);	//sub bg 0 will be used to print text
  
      BG3_CR = BG_RS_32x32 | BG_MAP_BASE(MAPBASE0)|BG_TILE_BASE(TILEBASE0)|BG_PRIORITY(3);
  
      SUB_BG3_CR =  BG_RS_32x32  | BG_MAP_BASE(SUBMAPBASE0)|BG_TILE_BASE(SUBTILEBASE0)|BG_PRIORITY(3);
      BG3_CX = 0;
      SUB_BG3_CX = 0;
      BG3_CY = 0;
      SUB_BG3_CY = 0;
    
      //make up a bad game over screen
      memset(BG_PALETTE,0,512);
      memset(BG_PALETTE_SUB,0,512);
  
      memset(bgMap0,0,2048);
      memset(bgSubMap0,0,2048);
  
      memset(bgTile0,0,65536);
      memset(bgSubTile0,0,65536); 
  
      pFile = fileIn("congratsN.pal",length);
      dmaCopy(pFile,BG_PALETTE_SUB,length);
      pFile = fileIn("happy.pal",length);
      dmaCopy(pFile,BG_PALETTE,length);
  
      pFile = fileIn("congratsN.map",length);
      dmaCopy(pFile,bgSubMap0,length);
      pFile = fileIn("happy.map",length);
      dmaCopy(pFile,bgMap0,length);
  
      pFile = fileIn("congratsN.tle",length);
      dmaCopy(pFile,bgSubTile0,length);
      pFile = fileIn("happy.tle",length);
      dmaCopy(pFile,bgTile0,length);
      for(int i = 0; i < 300; i++)
        swiWaitForVBlank();
      return true;
    }
  }
  
  return false;
}

void Setup()
{
  MapWidth = 200;
  MapHeight = 200;
  if(mainOnTop)
  {
    lcdSwap();
    mainOnTop = false;
  }
  u32 length = 0;
  int temp = 0;
  
  BGTILES = 0;
  TURKEYNUM = PLAYERS;
  frame = 0;
  tick = 0;
  redrawMapVB = false;
  redrawMap = false;
  videoSetMode   (MODE_5_2D | DISPLAY_BG3_ACTIVE);	//not using the main screen
	videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);	//sub bg 0 will be used to print text
  BG3_CX = 0;
  SUB_BG3_CX = 0;
  BG3_CY = 0;
  SUB_BG3_CY = 0;
    
  vramSetBankE(VRAM_E_MAIN_BG);
  vramSetBankA(VRAM_A_MAIN_BG_0x6020000);
  //vramSetBankB(VRAM_B_MAIN_BG_0x6040000);
  vramSetBankC(VRAM_C_SUB_BG_0x6200000);
  
  //vramSetBankD(VRAM_D_SUB_SPRITE);
  //vramSetBankH(VRAM_H_SUB_BG);
  vramSetBankG(VRAM_G_MAIN_SPRITE);

  vramSetBankI(VRAM_I_SUB_SPRITE);
  memset(BG_PALETTE,0,512);
  memset(BG_PALETTE_SUB,0,512);
  
  memset(bgMap0,0,2048);
  memset(bgSubMap0,0,2048);
  
  memset(bgTile0,0,65536);
  memset(bgSubTile0,0,65536); 
  
  pFile = fileIn("hunterhunted.pal",length);
  dmaCopy(pFile,BG_PALETTE_SUB,length);
  pFile = fileIn("hunterorhunted.pal",length);
  dmaCopy(pFile,BG_PALETTE,length);
  
  pFile = fileIn("hunterhunted.map",length);
  dmaCopy(pFile,bgMap0,length);
	pFile = fileIn("hunterorhunted.map",length);
  dmaCopy(pFile,bgSubMap0,length);
  
  pFile = fileIn("hunterhunted.tle",length);
  dmaCopy(pFile,bgTile0,length);
	pFile = fileIn("hunterorhunted.tle",length);
  dmaCopy(pFile,bgSubTile0,length);
  
  
	BG3_CR = BG_RS_32x32 | BG_MAP_BASE(MAPBASE0)|BG_TILE_BASE(TILEBASE0)|BG_PRIORITY(3);

  BG3_XDX = 1 << 8;
  BG3_XDY = 0;
  BG3_YDX = 0;
  BG3_YDY = 1 << 8;
  BG3_CX = 0;
  BG3_CY = 0;
  
	SUB_BG3_CR =  BG_RS_32x32  | BG_MAP_BASE(SUBMAPBASE0)|BG_TILE_BASE(SUBTILEBASE0)|BG_PRIORITY(3);

	SUB_BG3_XDX = 1 << 8;
  SUB_BG3_XDY = 0;
  SUB_BG3_YDX = 0;
  SUB_BG3_YDY = 1 << 8;
  SUB_BG3_CX = 0;
  SUB_BG3_CY = 0;

  for(int x = 0; x < 16; x++)
  {
    bgMap0[x + (7 * 32)] = 325; 
    bgMap0[x + (23* 32)] = 325; 
  
    bgMap0[16 + x + (7 * 32)] = 0; 
    bgMap0[16+ x + (23* 32)] = 0;
  }
  for(int y = 7; y < 24;y++)
  {
    bgMap0[y * 32] = 325; 
    bgMap0[15 + (y * 32)] = 325;
    bgMap0[16 + y * 32] = 0; 
    bgMap0[31 + (y * 32)] =0;
  }
  int playerChoice = NATIVE;
  while(1)
  {
    
    scanKeys();
    if(keysDown() & KEY_START)
      break;  
    if(keysDown() & KEY_LEFT)
    {
      playerChoice = NATIVE;
      for(int x = 0; x < 16; x++)
      {
         bgMap0[x + (7 * 32)] = 325; 
         bgMap0[x + (23* 32)] = 325; 
      
         bgMap0[16 + x + (7 * 32)] = 0; 
         bgMap0[16+ x + (23* 32)] = 0;
      }
      for(int y = 7; y < 24;y++)
      {
        bgMap0[y * 32] = 325; 
        bgMap0[15 + (y * 32)] = 325;
        bgMap0[16 + y * 32] = 0; 
        bgMap0[31 + (y * 32)] =0;
      }
    }
    else if(keysDown() & KEY_RIGHT)
    {
      playerChoice = TURKEY;
      for(int x = 16; x < 32; x++)
      {
         bgMap0[x + (7 * 32)] = 325; 
         bgMap0[x + (23* 32)] = 325; 
         bgMap0[x - 16 + (7 * 32)] = 0; 
         bgMap0[x - 16 + (23* 32)] = 0; 
      
      }
      for(int y = 7; y < 24;y++)
      {
        bgMap0[16 + y * 32] = 325; 
        bgMap0[31 + (y * 32)] = 325;
        bgMap0[y * 32] = 0; 
        bgMap0[15 + (y * 32)] = 0;
      }
    }
    srand(tick);
  }
  pFile = fileIn("mapsel.pal",length);
  dmaCopy(pFile,BG_PALETTE,length);
  
  pFile = fileIn("mapsel.map",length);
  dmaCopy(pFile,bgMap0,length);
  
  pFile = fileIn("mapsel.tle",length);
  dmaCopy(pFile,bgTile0,length);
  
  for(int x = 0; x < 16; x++)
  {
    bgMap0[x + (7 * 32)] = 325; 
    bgMap0[x + (23* 32)] = 325; 
  
    bgMap0[16 + x + (7 * 32)] = 0; 
    bgMap0[16+ x + (23* 32)] = 0;
  }
  for(int y = 7; y < 24;y++)
  {
    bgMap0[y * 32] = 325; 
    bgMap0[15 + (y * 32)] = 325;
    bgMap0[16 + y * 32] = 0; 
    bgMap0[31 + (y * 32)] =0;
  }
  while(1)
  {
    
    scanKeys();
    if(keysDown() & KEY_START)
      break;  
    if(keysDown() & KEY_A)
      break;  
    
    if(keysDown() & KEY_LEFT)
    {
      MapWidth = 200;
      MapHeight = 200;
      
      for(int x = 0; x < 16; x++)
      {
         bgMap0[x + (7 * 32)] = 325; 
         bgMap0[x + (23* 32)] = 325; 
      
         bgMap0[16 + x + (7 * 32)] = 0; 
         bgMap0[16+ x + (23* 32)] = 0;
      }
      for(int y = 7; y < 24;y++)
      {
        bgMap0[y * 32] = 325; 
        bgMap0[15 + (y * 32)] = 325;
        bgMap0[16 + y * 32] = 0; 
        bgMap0[31 + (y * 32)] =0;
      }
    }
    else if(keysDown() & KEY_RIGHT)
    {
      MapWidth = 1024;
      MapHeight = 1024;
      for(int x = 16; x < 32; x++)
      {
         bgMap0[x + (7 * 32)] = 325; 
         bgMap0[x + (23* 32)] = 325; 
         bgMap0[x - 16 + (7 * 32)] = 0; 
         bgMap0[x - 16 + (23* 32)] = 0; 
      
      }
      for(int y = 7; y < 24;y++)
      {
        bgMap0[16 + y * 32] = 325; 
        bgMap0[31 + (y * 32)] = 325;
        bgMap0[y * 32] = 0; 
        bgMap0[15 + (y * 32)] = 0;
      }
    }
    //srand(tick);
  }
  
  memset(BG_PALETTE,0,512);
  memset(BG_PALETTE_SUB,0,512);
  
  memset(bgMap0,0,2048);
  memset(bgSubMap0,0,2048);
  
  memset(bgTile0,0,65536);
  memset(bgSubTile0,0,65536);
  
  
  ai = new AIClass();
  ai->setMapSize(17,13);
  
	BG3_CR = BG_RS_64x64 | BG_MAP_BASE(MAPBASE0)|BG_TILE_BASE(TILEBASE0)|BG_PRIORITY(3);
	SUB_BG3_CR =  BG_RS_64x64  | BG_MAP_BASE(SUBMAPBASE0)|BG_TILE_BASE(SUBTILEBASE0)|BG_PRIORITY(3);


	BG2_CR = BG_RS_64x64 | BG_MAP_BASE(MAPBASE1)|BG_TILE_BASE(TILEBASE1)|BG_PRIORITY(0);

  BG2_XDX = 1 << 8;
  BG2_XDY = 0;
  BG2_YDX = 0;
  BG2_YDY = 1 << 8;
  BG2_CX = 0;
  BG2_CY = 0;
  
	SUB_BG2_CR =  BG_RS_64x64  | BG_MAP_BASE(SUBMAPBASE1)|BG_TILE_BASE(SUBTILEBASE1)|BG_PRIORITY(0);

	SUB_BG2_XDX = 1 << 8;
  SUB_BG2_XDY = 0;
  SUB_BG2_YDX = 0;
  SUB_BG2_YDY = 1 << 8;
  SUB_BG2_CX = 0;
  SUB_BG2_CY = 0;
  
  ai->fps = gbfs_get_obj(data_gbfs, "dig.bin", &length);
  
  pFile = fileIn("random.bin",length);
  for(u32 i = 0; i < length; i++)
    random[i] = ((u8*)pFile)[i];
  

  ///////////////////////////////////////
  ////////GENERATE MAP///////////////////
  //////////////////////////////////////
  for(int i = 0; i < MapWidth * MapHeight;i+=4)
	{
    if(!(i % MapWidth))
      randIndex = rand() % MapWidth;
  
    forest[i] = random[randIndex] & 31;
    randIndex++;
    randIndex %= MapWidth;
    forest[i + 1] = random[randIndex] & 31;
    randIndex++;
    randIndex %= MapWidth;
    forest[i + 2] = random[randIndex] & 31;
    randIndex++;
    randIndex %= MapWidth;
    forest[i + 3] = random[randIndex] & 31;
    randIndex++;
    randIndex %= MapWidth;
  }
  int x = 0; 
  int y = 0;
  int i = 0;

  while(1)
  {
    if(!(i & 255))
      randIndex = rand() % MapWidth;
  
    temp = random[randIndex] & 31;
    randIndex++;
    randIndex &= MapWidth;
    if (temp < 5)
    {
      forest[(x) + (y) * MapWidth] |= temp << 5;
      forest[(x+1) + (y) * MapWidth] |= temp << 5;
      forest[(x) + (y+1) * MapWidth] |= temp << 5;
      forest[(x+1) + (y+1) * MapWidth] |= temp << 5;
      
    }
    x +=2;
    if (x > MapWidth - 1)
    {
      x = 0;
      y+=2;
      if (y > MapHeight - 1)
      {
        break;
      }  
    }
    i++;
  }
 


  for(int z = 0; z < MapHeight + 1; z+=2)
  {
    for(int w = 0; w < 12; w+=2)
    {
      forest[(w) + (z) * MapWidth] = 3 << 5;
      forest[(w+1) + (z) * MapWidth] = 3 << 5;
      forest[(w) + (z+1) * MapWidth] = 3 << 5;
      forest[(w+1) + (z+1) * MapWidth] = 3 << 5;
      
      forest[(z) + (w) * MapWidth] = 3 << 5;
      forest[(z+1) + (w) * MapWidth] = 3 << 5;
      forest[(z) + (w+1) * MapWidth] = 3 << 5;
      forest[(z+1) + (w+1) * MapWidth] = 3 << 5;
      
      forest[(MapWidth-16 + w) + (z) * MapWidth] = 3 << 5;
      forest[(MapWidth-16 + w+1) + (z) * MapWidth] = 3 << 5;
      forest[(MapWidth-16 + w) + (z+1) * MapWidth] = 3 << 5;
      forest[(MapWidth-16 + w+1) + (z+1) * MapWidth] = 3 << 5;
      
      forest[(z) + (MapHeight-2 - w) * MapWidth] = 3 << 5;
      forest[(z+1) + (MapHeight-2 - w) * MapWidth] = 3 << 5;
      forest[(z) + (MapHeight-2 - w+1) * MapWidth] = 3 << 5;
      forest[(z+1) + (MapHeight-2 - w+1) * MapWidth] = 3 << 5;    
    }
    
    for(int w = 12; w < 15; w+=2)
    {
      forest[(w) + (z) * MapWidth] = 3 << 5;
      forest[(w+1) + (z) * MapWidth] = 3 << 5;
      forest[(w) + (z+1) * MapWidth] = 3 << 5;
      forest[(w+1) + (z+1) * MapWidth] = 3 << 5;
      
      forest[(MapWidth - 16+w) + (z) * MapWidth] = 3 << 5;
      forest[(MapWidth-16+w+1) + (z) * MapWidth] = 3 << 5;
      forest[(MapWidth-16+w) + (z+1) * MapWidth] = 3 << 5;
      forest[(MapWidth-16+w+1) + (z+1) * MapWidth] = 3 << 5;
    }
  }  
  
  
	
  irqEnable(IRQ_VBLANK);
  
  //consoleInit() is a lot more flexible but this gets you up and running quick
	//consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
  
  if(playerChoice == TURKEY)
  {
    turkey[0].X = 0;
    turkey[0].Y = 0;
    while(1)
    {
      turkey[0].mapX = rand() % (MapWidth - 18);
      turkey[0].mapY = rand() % (MapHeight - 18);
      turkey[0].posX = (turkey[0].mapX + 15) * 8 + (turkey[0].X >> 12);
      turkey[0].posY = (turkey[0].mapY + 11) * 8 + (turkey[0].Y >> 12);
      if((forest[(turkey[0].posX>>3) + (turkey[0].posY>>3) * MapWidth] >> 5) == 0)
        break;
    }
    turkey[0].spr = TURKEYSTART;
    turkey[0].rot = DEGDOWN;
    turkey[0].deg = DEGDOWN;
    turkey[0].speed = 5;
    turkey[0].input = PAD;
    turkey[0].type = TURKEY;
    turkey[0].life = 5;
    turkey[0].container = 5;
    turkey[0].mate = true;
  
    turkey[1].X = 0;
    turkey[1].Y = 0;
  
    while(1)
    {
      turkey[1].mapX = rand() % (MapWidth - 18);
      turkey[1].mapY = rand() % (MapHeight - 18);
      turkey[1].posX = (turkey[1].mapX + 15) * 8 + (turkey[1].X >> 12);
      turkey[1].posY = (turkey[1].mapY + 11) * 8 + (turkey[1].Y >> 12);
      if((forest[(turkey[1].posX>>3) + (turkey[1].posY>>3) * MapWidth] >> 5) == 0)
        break;
    }
    turkey[1].spr = TURKEYSTART;
    turkey[1].rot = DEGDOWN;
    turkey[1].deg = DEGDOWN;
    turkey[1].speed = 5;
    turkey[1].input = AI;
    turkey[1].type = TURKEY;
    turkey[1].life = 5;
    turkey[1].container = 5;
    turkey[1].mate = true;

    for(int i = 2; i < TURKEYNUM; i++)
    {
      
      
      turkey[i].X = 0;
      turkey[i].Y = 0;

      while(1)
      {
        turkey[i].mapX = rand() % (MapWidth - 18);
        turkey[i].mapY = rand() % (MapHeight - 18);
        turkey[i].posX = (turkey[i].mapX + 15) * 8 + (turkey[i].X >> 12);
        turkey[i].posY = (turkey[i].mapY + 11) * 8 + (turkey[i].Y >> 12);
        if((forest[(turkey[i].posX>>3) + (turkey[i].posY>>3) * MapWidth] >> 5) == 0)
          break;
      }

      turkey[i].spr = NATIVESTART;
      turkey[i].rot = DEGDOWN;
      turkey[i].deg = DEGDOWN;
      turkey[i].speed = 5;
      turkey[i].input = AI;
      turkey[i].type = NATIVE;
      turkey[i].life = 5;
      turkey[i].container = 5;
      turkey[i].mate = false;
    }
    
  }
  if(playerChoice == NATIVE)
  {
    turkey[0].X = 0;
    turkey[0].Y = 0;
    while(1)
    {
      turkey[0].mapX = rand() % (MapWidth - 18);
      turkey[0].mapY = rand() % (MapHeight - 18);
      turkey[0].posX = (turkey[0].mapX + 15) * 8 + (turkey[0].X >> 12);
      turkey[0].posY = (turkey[0].mapY + 11) * 8 + (turkey[0].Y >> 12);
      if(((forest[(turkey[0].posX>>3)  + (turkey[0].posY>>3) * MapWidth] >> 5) == 0) &&
         ((forest[((turkey[0].posX>>3) + 1) + (turkey[0].posY>>3) * MapWidth] >> 5) == 0) &&
         ((forest[(turkey[0].posX>>3) + ((turkey[0].posY>>3)+1) * MapWidth] >> 5) == 0) &&
         ((forest[((turkey[0].posX>>3) + 1) + ((turkey[0].posY>>3)+1) * MapWidth] >> 5) == 0))
        break;
    }
    turkey[0].spr = NATIVESTART;
    turkey[0].rot = DEGDOWN;
    turkey[0].deg = DEGDOWN;
    turkey[0].speed = 5;
    turkey[0].input = PAD;
    turkey[0].type = NATIVE;
    turkey[0].life = 5;
    turkey[0].container = 5;
    turkey[0].mate = false;
  
    turkey[1].X = 0;
    turkey[1].Y = 0;
    while(1)
    {
      
      turkey[1].mapX = rand() % (MapWidth - 18);
      turkey[1].mapY = rand() % (MapHeight - 18);
      turkey[1].posX = (turkey[1].mapX + 15) * 8 + (turkey[1].X >> 12);
      turkey[1].posY = (turkey[1].mapY + 11) * 8 + (turkey[1].Y >> 12);
      if(((forest[(turkey[1].posX>>3)  + (turkey[1].posY>>3) * MapWidth] >> 5) == 0) &&
         ((forest[((turkey[1].posX>>3) + 1) + (turkey[1].posY>>3) * MapWidth] >> 5) == 0) &&
         ((forest[(turkey[1].posX>>3) + ((turkey[1].posY>>3)+1) * MapWidth] >> 5) == 0) &&
         ((forest[((turkey[1].posX>>3) + 1) + ((turkey[1].posY>>3)+1) * MapWidth] >> 5) == 0))
           break;
        }
    turkey[1].spr = NATIVESTART;
    turkey[1].rot = DEGDOWN;
    turkey[1].deg = DEGDOWN;
    turkey[1].speed = 5;
    turkey[1].input = AI;
    turkey[1].type = NATIVE;
    turkey[1].life = 5;
    turkey[1].container = 5;
    turkey[1].mate = false;
  
    for(int i = 2; i < TURKEYNUM; i++)
    {
      turkey[i].X = 0;
      turkey[i].Y = 0;
      while(1)
      {
        turkey[i].mapX = rand() % (MapWidth - 18);
        turkey[i].mapY = rand() % (MapHeight - 18);
        turkey[i].posX = (turkey[i].mapX + 15) * 8 + (turkey[i].X >> 12);
        turkey[i].posY = (turkey[i].mapY + 11) * 8 + (turkey[i].Y >> 12);
        if(((forest[(turkey[i].posX>>3)  + (turkey[i].posY>>3) * MapWidth] >> 5) == 0) &&
         ((forest[((turkey[i].posX>>3) + 1) + (turkey[i].posY>>3) * MapWidth] >> 5) == 0) &&
         ((forest[(turkey[i].posX>>3) + ((turkey[i].posY>>3)+1) * MapWidth] >> 5) == 0) &&
         ((forest[((turkey[i].posX>>3) + 1) + ((turkey[i].posY>>3)+1) * MapWidth] >> 5) == 0))
          break;
      }
      turkey[i].spr = TURKEYSTART;
      turkey[i].rot = DEGDOWN;
      turkey[i].deg = DEGDOWN;
      turkey[i].speed = 5;
      turkey[i].input = AI;
      turkey[i].type = TURKEY;
      turkey[i].life = 5;
      turkey[i].container = 5;
      turkey[i].mate = false;
    }
  }
  
    
  pFile = fileIn("terrain.pal",length);
  dmaCopy(pFile,BG_PALETTE,length);
  dmaCopy(pFile,BG_PALETTE_SUB,length);
  
  pFile = fileIn("terrain.tle",length);
  dmaCopy(pFile,bgSubTile0,length);
	dmaCopy(pFile,bgTile0,length);
  BGTILES = length / 64;
  initSprites();
  
  int sprSpot = 0;
  int sprSubSpot = 0;
  pFile = fileIn("turkey.pal",length);
  dmaCopy(pFile,SPRITE_PALETTE_SUB,length);
	dmaCopy(pFile,SPRITE_PALETTE,length);
  
  pFile = fileIn("turkey.spr",length);
  dmaCopy(pFile,SPRITE_GFX_SUB,length);
	dmaCopy(pFile,SPRITE_GFX,length);
  sprSpot += length;
  sprSubSpot += length;
  
  pFile = fileIn("arrow.pal",length);
  dmaCopy(pFile,&SPRITE_PALETTE_SUB[15*16],length);
	dmaCopy(pFile,&SPRITE_PALETTE[15*16],length);
  
  pFile = fileIn("arrow.spr",length);
  dmaCopy(pFile,&SPRITE_GFX_SUB[sprSubSpot / 2],length);
	dmaCopy(pFile,&SPRITE_GFX[sprSpot / 2],length);
  arrowStart = sprSpot / 32 ;
  sprSpot += length;
  sprSubSpot += length;
  
  
  pFile = fileIn("arrows.pal",length);
  dmaCopy(pFile,&SPRITE_PALETTE_SUB[14*16],length);
	dmaCopy(pFile,&SPRITE_PALETTE[14*16],length);
  
  pFile = fileIn("arrows.spr",length);
  dmaCopy(pFile,&SPRITE_GFX_SUB[sprSubSpot / 2],length);
	dmaCopy(pFile,&SPRITE_GFX[sprSpot / 2],length);
  sprSpot += length;
  sprSubSpot += length;

  pFile = fileIn("dig.bin",length);
  dmaCopy(pFile,&SPRITE_GFX_SUB[sprSubSpot / 2],length);
	dmaCopy(pFile,&SPRITE_GFX[sprSpot / 2],length);
  
  digStart = sprSpot / 32;
  sprSpot += length;
  sprSubSpot += length;

  pFile = fileIn("x.bin",length);
  dmaCopy(pFile,&SPRITE_GFX_SUB[sprSubSpot / 2],length);
	dmaCopy(pFile,&SPRITE_GFX[sprSpot / 2],length);
  
  redrawMapVB = true;
  redrawMap = true;
  
  videoSetMode   (MODE_5_2D | DISPLAY_BG2_ACTIVE | DISPLAY_BG3_ACTIVE | DISPLAY_SPR_ACTIVE|DISPLAY_SPR_1D);	//not using the main screen
	videoSetModeSub(MODE_5_2D | DISPLAY_BG2_ACTIVE | DISPLAY_BG3_ACTIVE | DISPLAY_SPR_ACTIVE|DISPLAY_SPR_1D);	//sub bg 0 will be used to print text
  }
