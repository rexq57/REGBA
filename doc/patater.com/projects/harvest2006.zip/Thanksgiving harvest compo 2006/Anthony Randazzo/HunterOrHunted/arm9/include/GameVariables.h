//FileName: GameVariables.h
//Date Modified 11 February 2005
//Version: 0.022205.23:03
//Team: AI
//Author: Anthony Randazzo
//Purpose: Header File for various data needed for classes
//#include "stdafx.h"
#include <nds.h>
#ifndef GAMEVARIABLES_H
#define GAMEVARIABLES_H

enum AIMAP
{
  AI_NONE, 
  AI_OPENED,
  AI_CLOSED,
  AI_OBSTACLE,
  AI_ENEMY,
  AI_FRIEND,
  AI_COVER,
  AI_GOAL
};

#define ABS(X) (((X)<0)?(-(X)):(X))

#define TOTHERIGHT 1
#define INFRONT    2
#define TOTHELEFT  4
#define BEHIND     8 

enum AIDIR
{
AI_SOUTH,      
AI_SOUTHWEST,  
AI_WEST,       
AI_NORTHWEST,  
AI_NORTH,      
AI_NORTHEAST,  
AI_EAST,       
AI_SOUTHEAST,  
AI_NO_DIR     

};
//#define heuristic(col1,row1,col2,row2) (((ABS((col1) - (col2))) + (ABS((row1) - (row2)))))
#define SQR(x) (x) * (x) 
#define heuristic(col1,row1,col2,row2) (((SQR((col1) - (col2))) + (SQR((row1) - (row2)))))
  
enum DEGREE
{
  DEGDOWN,
  DEGDOWNLEFT,
  DEGLEFT,
  DEGUPLEFT,
  DEGUP,
  DEGUPRIGHT,
  DEGRIGHT,
  DEGDOWNRIGHT,
  FLIP
};
//#define SIZEOFSNAKE 2


#define TURNCOUNTERCLOCKWISE 1
#define TURNCLOCKWISE        1
#define MAXUINT 0xCCCCCCCC
#define MAXINT   32000

#define TOTAL_PATH_LENGTH 825

#define HEARTSMALL 96
#define HEARTBIG 104
#define HEARTEMPTY 112

enum Input
{
  PAD,
  AI
};

enum PlayerType
{
  TURKEY = 0,
  NATIVE = 1
};
// Construction
struct posit
{
  u8 Col;
  u8 Row;
  AIDIR dir;
};



struct node
{
  u32 Col;
  u32 Row;
  AIDIR dir;
  u32 preCol;
  u32 preRow;
  u32 score;
  u32 heuristic;
  u32 startcost;
  AIMAP status;
};

struct TurkeyData
{
  int X;
  int Y;
  u32 mapX;
  u32 mapY;
  u32 posX;
  u32 posY;
  int spr;
  DEGREE rot;
  DEGREE deg;
  int speed;
  Input input;
  PlayerType type;
  bool projectile;
  DEGREE projectileDeg;
  u32 projectilePosX;
  u32 projectilePosY;
  int projectileSpr;
  int projectileCounter;
  int life;
  int container;
  bool sound;
  int soundCounter;
  bool mate;
};

struct ArrowData
{
  int x;
  int y;
  int spr;
  int screen;
  int deg;
  int visible;
};


struct AIPLOT 
{
  int x;
  int y;
};



struct WAVEHEADER
{
  u8 riffID[4];         //contains identifier "RIFF"
  u32 riffSIZE;           //File size minus 8 bytes
  u8 riffFORMAT[4];     //contains identifier "WAVE"
  u8 fmtID[4];          //contains identifier: "fmt " (with
                            //space)
  u32 fmtSIZE;            //contains the size of this block
                            //(for WAVE PCM 16)
  u16 wFormatTag;          //format of digital sound
  u16 nChannels;           //Number of channels (1 for mono and
                            //2 for stereo)
  u32 nSamplesPerSec;     //Number of samples per second
  u32 nAvgBytesPerSec;    //Average number bytes of data per
                            //second
  u16 nBlockAlign;         //Minimal data size for playing
  u16 wBitsPerSample;      //Bits per sample (8 or 16)
  u8 dataID[4];         //contains identifier: "data"
  u32 dataSIZE;           //data size
};

#endif
