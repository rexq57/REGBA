//FileName: AIClass.h
//Date Modified 05 May 2005
//Version: 3.0
//Team: AI
//Author: Anthony Randazzo
//Purpose: Header File to Implement the AI

#include "GameVariables.h"
#include  <stdio.h>
#include  <math.h>
#include  <stdlib.h>
#include <vector>
#ifndef AICLASS_H
#define AICLASS_H
//#define DEBUG 0
#define NUM_OF_AI 1
#define MAX_NUM_OF_ITEMS 100
class AIClass
{

  protected:
  //Variables
  u32 lastKeyInput;
  int deltaCOL[16];
  int deltaROW[16];
  int AIMove[NUM_OF_AI];
  
  bool chase[NUM_OF_AI];
  posit AIPath[NUM_OF_AI][TOTAL_PATH_LENGTH];
  int AIPathLength[NUM_OF_AI];
  posit AIPathToMe[NUM_OF_AI][TOTAL_PATH_LENGTH];
  int AIPathToMeLength[NUM_OF_AI];

  //Functions
 // int  heuristic(int,int,int,int);
//  void getBestItemPath(posit AIposition[], vector<item> Item[]);
  void nodeEqual(node &node1, node &node2);
  
  void ShortestPath(TurkeyData &myPosition, TurkeyData &targetPosition,posit* path, int &pathLength, int player, int tick = -1);
  
  void getOppenentPathToMe(posit oppsPos,int oppsID, int myID, int tick);
  void positEqual(posit a, posit b);
  void setMove(int AIPlayer, int moves);
//  void testPath(posit AIposition[],vector<item> Item[]);
  int score[NUM_OF_AI];
  int snakeLength[NUM_OF_AI];
  int returnItemPointValue(int enumNum, int lengths);
  posit path[25*33];

public:
//  vector<u16> brain;
  //AIClass();
  AIClass();
  ~AIClass();
  void Debug();
  void setMapSize(int,int);
//  void getPath(posit AIposition[], vector<item> Items[], vector<item> Bad[], Maze maze[64][64], int scores[], int lengthy[]);
  int  getMove(int AIPlayer);
  void setMap(int x,int y , int status);
  bool checkProjectile(TurkeyData);
  u32 MapWidth;
  u32 MapHeight;
  node* MapList;
  const void* fps;
  int getInput(TurkeyData &turkeyz);
  posit enemyArray[500];
  posit friendArray[500];
  posit coverArray[500];
  u32 enemyCnt;
  u32 friendCnt;
  u32 coverCnt;
    
};
#endif
