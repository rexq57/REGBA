#include <stdio.h>
#include <sys/stat.h>
#include <nds.h>
#include <gbfs.h>				// filesystem functions
extern const GBFS_FILE*  data_gbfs;
FILE* fileIn(char*fileName,u32 &length)
{
  FILE* fps;
  struct stat info;

  fps = fopen(fileName,"rb");
  if(!fps)
    return (FILE*)gbfs_get_obj(data_gbfs, fileName, &length);
  else
  {
    if (stat(fileName, &info) != 0)
      perror("stat() error");
    length = info.st_size;
    return fps;
  }
}

FILE* fileIn(char*fileName)
{
  
  struct stat info;
  FILE* fps;
  fps = fopen(fileName,"rb");
  if(!fps)
    return (FILE*)gbfs_get_obj(data_gbfs, fileName, NULL);
  else
  {
    if (stat(fileName, &info) != 0)
      perror("stat() error");
    
    return fps;
  }
}

