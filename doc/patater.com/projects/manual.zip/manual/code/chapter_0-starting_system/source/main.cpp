#include <nds.h>

int main() {

    /* This program doesn't do very much, yet. */

	return 0;
}
